<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669eebb8a3e37             |
    |_______________________________________|
*/
 use Pmpr\Module\OptimizationManager\OptimizationManager; OptimizationManager::symcgieuakksimmu();
