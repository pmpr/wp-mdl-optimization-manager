<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66aeb5d2abe77             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Module\OptimizationManager\Traits\CommonTrait; abstract class Container extends BaseClass { use CommonTrait; const aksyiucmwcsqgese = "\x6f\x70\x74\x69\x6d\x69\x7a\x61\x74\x69\157\x6e\137\x6d\x61\156\141\x67\145\162\137"; public function ikcgmcycisiccyuc() { $this->settingObj = Setting::symcgieuakksimmu(); } }
