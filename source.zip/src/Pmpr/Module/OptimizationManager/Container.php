<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66b6188ad9125             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Module\OptimizationManager\Traits\CommonTrait; abstract class Container extends BaseClass { use CommonTrait; const aksyiucmwcsqgese = "\x6f\160\164\x69\155\151\172\141\x74\x69\x6f\156\x5f\x6d\x61\x6e\141\x67\x65\x72\137"; public function ikcgmcycisiccyuc() { $this->settingObj = Setting::symcgieuakksimmu(); } }
