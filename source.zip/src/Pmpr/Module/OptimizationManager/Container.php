<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66868667851c5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Module\OptimizationManager\Traits\CommonTrait; abstract class Container extends BaseClass { use CommonTrait; const aksyiucmwcsqgese = "\157\160\x74\x69\x6d\151\172\141\164\151\x6f\x6e\137\x6d\x61\156\x61\147\145\x72\137"; public function ikcgmcycisiccyuc() { $this->settingObj = Setting::symcgieuakksimmu(); } }
