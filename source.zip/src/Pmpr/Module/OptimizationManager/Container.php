<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668daba42442f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Module\OptimizationManager\Traits\CommonTrait; abstract class Container extends BaseClass { use CommonTrait; const aksyiucmwcsqgese = "\157\x70\x74\x69\x6d\151\172\141\x74\151\x6f\156\x5f\x6d\141\x6e\141\x67\145\162\137"; public function ikcgmcycisiccyuc() { $this->settingObj = Setting::symcgieuakksimmu(); } }
