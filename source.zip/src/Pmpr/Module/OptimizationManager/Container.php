<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6689580cec3a1             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Module\OptimizationManager\Traits\CommonTrait; abstract class Container extends BaseClass { use CommonTrait; const aksyiucmwcsqgese = "\x6f\x70\x74\151\155\151\172\141\x74\x69\x6f\x6e\137\155\141\x6e\141\147\145\162\x5f"; public function ikcgmcycisiccyuc() { $this->settingObj = Setting::symcgieuakksimmu(); } }
