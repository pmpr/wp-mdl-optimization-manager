<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668107472aaf4             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Traits; use Pmpr\Common\Foundation\Manipulate\Type\ManipulateArray; trait CommonTrait { public function qqmwsmimiiiqkooo(?string $iqaosyayeiuaisqi = null) : array { $xwwgygqkqwuaqwsa = [self::yygyasgygkeqacou => __("\x4c\x65\x76\145\154\x20\x31", PR__MDL__OPTIMIZATION_MANAGER), self::cwoackywkgsameww => __("\114\x65\x76\145\x6c\x20\62", PR__MDL__OPTIMIZATION_MANAGER)]; return ManipulateArray::get($xwwgygqkqwuaqwsa, $iqaosyayeiuaisqi, $xwwgygqkqwuaqwsa); } }
