<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66871ee971196             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Traits; use Pmpr\Common\Foundation\Manipulate\Type\ManipulateArray; trait CommonTrait { public function qqmwsmimiiiqkooo(?string $iqaosyayeiuaisqi = null) : array { $xwwgygqkqwuaqwsa = [self::yygyasgygkeqacou => __("\x4c\145\166\145\154\40\x31", PR__MDL__OPTIMIZATION_MANAGER), self::cwoackywkgsameww => __("\x4c\x65\x76\145\154\40\x32", PR__MDL__OPTIMIZATION_MANAGER)]; return ManipulateArray::get($xwwgygqkqwuaqwsa, $iqaosyayeiuaisqi, $xwwgygqkqwuaqwsa); } }
