<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ab90b7db1ad             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Traits; use Pmpr\Common\Foundation\Manipulate\Type\ManipulateArray; trait CommonTrait { public function qqmwsmimiiiqkooo(?string $iqaosyayeiuaisqi = null) : array { $xwwgygqkqwuaqwsa = [self::yygyasgygkeqacou => __("\x4c\145\x76\145\154\40\x31", PR__MDL__OPTIMIZATION_MANAGER), self::cwoackywkgsameww => __("\114\145\166\x65\154\40\62", PR__MDL__OPTIMIZATION_MANAGER)]; return ManipulateArray::get($xwwgygqkqwuaqwsa, $iqaosyayeiuaisqi, $xwwgygqkqwuaqwsa); } }
