<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668daba42442f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Traits; use Pmpr\Common\Foundation\Manipulate\Type\ManipulateArray; trait CommonTrait { public function qqmwsmimiiiqkooo(?string $iqaosyayeiuaisqi = null) : array { $xwwgygqkqwuaqwsa = [self::yygyasgygkeqacou => __("\x4c\x65\166\145\154\40\61", PR__MDL__OPTIMIZATION_MANAGER), self::cwoackywkgsameww => __("\114\145\166\145\154\40\62", PR__MDL__OPTIMIZATION_MANAGER)]; return ManipulateArray::get($xwwgygqkqwuaqwsa, $iqaosyayeiuaisqi, $xwwgygqkqwuaqwsa); } }
