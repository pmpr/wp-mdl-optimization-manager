<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669c38b3da912             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Traits; use Pmpr\Common\Foundation\Manipulate\Type\ManipulateArray; trait CommonTrait { public function qqmwsmimiiiqkooo(?string $iqaosyayeiuaisqi = null) : array { $xwwgygqkqwuaqwsa = [self::yygyasgygkeqacou => __("\x4c\145\x76\x65\154\40\x31", PR__MDL__OPTIMIZATION_MANAGER), self::cwoackywkgsameww => __("\114\x65\x76\145\x6c\x20\x32", PR__MDL__OPTIMIZATION_MANAGER)]; return ManipulateArray::get($xwwgygqkqwuaqwsa, $iqaosyayeiuaisqi, $xwwgygqkqwuaqwsa); } }
