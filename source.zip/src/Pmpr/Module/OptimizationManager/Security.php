<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669ada84df097             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager; use Pmpr\Module\Security\AbstractSecurity; class Security extends AbstractSecurity { const eugkiogoakkiwism = "\160\x72\x69\x63\x69\156\x67\x5f\162\145\143\141\160\164\143\x68\x61"; public function ikcgmcycisiccyuc() { $this->setting = Setting::symcgieuakksimmu(); } public function iucqycygmekqcggo() : array { return [$this->wcwmusaouiqaqeww(self::eugkiogoakkiwism)->gswweykyogmsyawy(__("\120\162\151\143\151\156\x67\x20\x4d\165\x6c\x74\151\163\164\145\160", PR__MDL__CONTACT))->gucwmccyimoagwcm(__("\105\156\141\142\154\145\40\x72\x65\103\101\120\124\103\x48\101\40\x66\x6f\x72\x20\x70\162\x69\143\x69\156\147\x20\x70\141\147\x65\x20\155\165\x6c\x74\151\163\164\x65\160\56", PR__MDL__OPTIMIZATION_MANAGER))]; } public function ikaseommceygisqu($sogksuscggsicmac, $icwicymcioeyeyek) { return $sogksuscggsicmac; } }
