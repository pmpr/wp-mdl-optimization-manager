<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669c38b3da912             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager; use Pmpr\Module\Security\AbstractSecurity; class Security extends AbstractSecurity { const eugkiogoakkiwism = "\x70\162\x69\x63\x69\156\147\137\162\145\143\x61\160\164\143\x68\x61"; public function ikcgmcycisiccyuc() { $this->setting = Setting::symcgieuakksimmu(); } public function iucqycygmekqcggo() : array { return [$this->wcwmusaouiqaqeww(self::eugkiogoakkiwism)->gswweykyogmsyawy(__("\x50\162\151\x63\x69\156\x67\x20\115\x75\154\x74\x69\163\164\145\160", PR__MDL__CONTACT))->gucwmccyimoagwcm(__("\105\x6e\x61\142\x6c\145\x20\x72\x65\103\101\x50\x54\x43\x48\x41\40\146\157\162\x20\x70\x72\x69\x63\x69\156\x67\40\160\x61\x67\145\x20\155\165\x6c\x74\x69\x73\164\x65\x70\x2e", PR__MDL__OPTIMIZATION_MANAGER))]; } public function ikaseommceygisqu($sogksuscggsicmac, $icwicymcioeyeyek) { return $sogksuscggsicmac; } }
