<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68cc7218d5152             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\REST; use Pmpr\Common\Foundation\REST\RESTController; class Controller extends RESTController { public function ikcgmcycisiccyuc() { $this->rest_base = 'optimization-manager'; } }
