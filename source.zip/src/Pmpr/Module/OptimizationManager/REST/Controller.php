<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a2f4544fcb3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\REST; use Pmpr\Common\Foundation\REST\RESTController; class Controller extends RESTController { public function ikcgmcycisiccyuc() { $this->rest_base = "\157\x70\x74\151\155\151\172\x61\x74\x69\x6f\x6e\55\x6d\141\156\x61\147\145\x72"; } }
