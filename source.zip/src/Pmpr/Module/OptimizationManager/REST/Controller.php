<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             680177152c08b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\REST; use Pmpr\Common\Foundation\REST\RESTController; class Controller extends RESTController { public function ikcgmcycisiccyuc() { $this->rest_base = 'optimization-manager'; } }
