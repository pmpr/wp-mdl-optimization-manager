<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc5806a0ec             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\REST; use Pmpr\Common\Foundation\REST\RESTController; class Controller extends RESTController { public function ikcgmcycisiccyuc() { $this->rest_base = "\x6f\160\164\151\155\x69\x7a\141\164\x69\x6f\156\x2d\155\141\x6e\x61\147\145\162"; } }
