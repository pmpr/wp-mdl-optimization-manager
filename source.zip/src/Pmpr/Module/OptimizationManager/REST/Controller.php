<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66788387d2261             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\REST; use Pmpr\Common\Foundation\REST\RESTController; class Controller extends RESTController { public function ikcgmcycisiccyuc() { $this->rest_base = "\x6f\160\x74\151\x6d\151\x7a\x61\x74\x69\x6f\x6e\55\155\141\156\141\147\x65\x72"; } }
