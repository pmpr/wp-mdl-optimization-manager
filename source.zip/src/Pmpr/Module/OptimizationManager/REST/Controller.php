<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f7d63a82ae5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\REST; use Pmpr\Common\Foundation\REST\RESTController; class Controller extends RESTController { public function ikcgmcycisiccyuc() { $this->rest_base = "\x6f\160\164\x69\x6d\x69\172\141\x74\x69\x6f\x6e\55\155\141\156\x61\x67\x65\x72"; } }
