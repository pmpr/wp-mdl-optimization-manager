<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f6b052f0c6a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\REST; use Pmpr\Common\Foundation\REST\RESTController; class Controller extends RESTController { public function ikcgmcycisiccyuc() { $this->rest_base = "\157\x70\164\x69\x6d\151\x7a\x61\164\151\x6f\x6e\x2d\155\141\156\x61\147\145\x72"; } }
