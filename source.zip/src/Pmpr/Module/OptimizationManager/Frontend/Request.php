<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678d3d4831ce0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Frontend; use Pmpr\Common\Foundation\Frontend\Page; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\OptimizationManager\Setting; class Request extends Page { public function qiccuiwooiquycsg() { $this->wegcaymyqqoyewmw("\x77\160\x2d\x73\x70\x65\x65\144\x2d\x72\x65\x71\x75\x65\x73\164")->sqemekeuykmooums()->gswweykyogmsyawy(__("\x4f\x70\x74\x69\155\x69\x7a\141\x74\151\157\x6e\40\115\157\x64\x75\154\145\40\x52\145\161\165\145\x73\x74\40\x50\141\147\145", PR__MDL__OPTIMIZATION_MANAGER))->wmsaakuicamguoam($this->weysguygiseoukqw(Setting::eiguikqsqiemumcm, 0)); } public function rsysgcucogueguuk() : array { return [Constants::qescuiwgsyuikume => $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->qcgakseyaikigqco($this->iooowgsqoyqseyuu()), Constants::ccggwaweegsyygga => RequestMultistep::symcgieuakksimmu()->yqqscekqmcgwkiao(), Constants::eqkeooqcsscoggia => $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->masoymaamekuykso($this->iooowgsqoyqseyuu(), true)]; } }
