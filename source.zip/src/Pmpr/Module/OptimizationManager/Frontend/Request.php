<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66b6188ad9125             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Frontend; use Pmpr\Common\Foundation\Frontend\Page; use Pmpr\Module\OptimizationManager\Setting; class Request extends Page { public function qiccuiwooiquycsg() { $this->wegcaymyqqoyewmw("\167\160\55\x73\160\145\145\x64\x2d\x72\x65\x71\x75\x65\163\x74")->sqemekeuykmooums()->gswweykyogmsyawy(__("\117\x70\164\x69\155\x69\x7a\x61\x74\151\157\x6e\x20\x4d\157\x64\x75\154\145\40\122\x65\161\x75\145\x73\164\x20\120\141\x67\x65", PR__MDL__OPTIMIZATION_MANAGER))->wmsaakuicamguoam((int) Setting::symcgieuakksimmu()->giiuwsmyumqwwiyq(Setting::eiguikqsqiemumcm, 0)); } public function aosyekoskegecumg($amakmumgguksgmum) { parent::aosyekoskegecumg($amakmumgguksgmum); } public function rsysgcucogueguuk() : array { return [self::qescuiwgsyuikume => $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->qcgakseyaikigqco($this->iooowgsqoyqseyuu()), self::ccggwaweegsyygga => RequestMultistep::symcgieuakksimmu()->yqqscekqmcgwkiao(), self::eqkeooqcsscoggia => $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->masoymaamekuykso($this->iooowgsqoyqseyuu(), true)]; } }
