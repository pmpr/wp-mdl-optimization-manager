<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a2f4544fcb3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Frontend; use Pmpr\Common\Foundation\Frontend\Page; use Pmpr\Module\OptimizationManager\Setting; class Request extends Page { public function qiccuiwooiquycsg() { $this->wegcaymyqqoyewmw("\x77\x70\x2d\x73\160\145\x65\x64\55\x72\x65\x71\165\x65\163\164")->sqemekeuykmooums()->gswweykyogmsyawy(__("\117\160\164\151\x6d\151\172\x61\164\151\x6f\156\x20\x4d\157\x64\x75\154\145\40\x52\x65\x71\165\145\163\x74\40\x50\x61\147\145", PR__MDL__OPTIMIZATION_MANAGER))->wmsaakuicamguoam((int) Setting::symcgieuakksimmu()->giiuwsmyumqwwiyq(Setting::eiguikqsqiemumcm, 0)); } public function aosyekoskegecumg($amakmumgguksgmum) { parent::aosyekoskegecumg($amakmumgguksgmum); } public function rsysgcucogueguuk() : array { return [self::qescuiwgsyuikume => $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->qcgakseyaikigqco($this->iooowgsqoyqseyuu()), self::ccggwaweegsyygga => RequestMultistep::symcgieuakksimmu()->yqqscekqmcgwkiao(), self::eqkeooqcsscoggia => $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->masoymaamekuykso($this->iooowgsqoyqseyuu(), true)]; } }
