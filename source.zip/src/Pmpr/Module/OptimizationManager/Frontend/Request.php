<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66c31d588b892             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Frontend; use Pmpr\Common\Foundation\Frontend\Page; use Pmpr\Module\OptimizationManager\Setting; class Request extends Page { public function qiccuiwooiquycsg() { $this->wegcaymyqqoyewmw("\x77\160\55\163\160\x65\145\144\x2d\x72\x65\161\x75\145\x73\x74")->sqemekeuykmooums()->gswweykyogmsyawy(__("\x4f\x70\164\151\x6d\x69\172\141\x74\151\157\156\x20\115\x6f\x64\x75\154\x65\x20\x52\145\161\165\x65\x73\164\x20\120\141\147\145", PR__MDL__OPTIMIZATION_MANAGER))->wmsaakuicamguoam((int) Setting::symcgieuakksimmu()->giiuwsmyumqwwiyq(Setting::eiguikqsqiemumcm, 0)); } public function rsysgcucogueguuk() : array { return [self::qescuiwgsyuikume => $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->qcgakseyaikigqco($this->iooowgsqoyqseyuu()), self::ccggwaweegsyygga => RequestMultistep::symcgieuakksimmu()->yqqscekqmcgwkiao(), self::eqkeooqcsscoggia => $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->masoymaamekuykso($this->iooowgsqoyqseyuu(), true)]; } }
