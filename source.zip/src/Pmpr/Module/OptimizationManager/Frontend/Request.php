<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d86280bb1d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Frontend; use Pmpr\Common\Foundation\Frontend\Page; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\OptimizationManager\Setting; class Request extends Page { public function qiccuiwooiquycsg() { $this->wegcaymyqqoyewmw("\167\160\x2d\x73\x70\x65\x65\144\55\162\x65\161\165\x65\163\x74")->sqemekeuykmooums()->gswweykyogmsyawy(__("\117\x70\164\x69\x6d\x69\x7a\x61\164\x69\157\156\40\x4d\x6f\x64\x75\154\145\x20\x52\145\x71\x75\145\x73\x74\x20\x50\141\x67\145", PR__MDL__OPTIMIZATION_MANAGER))->wmsaakuicamguoam($this->weysguygiseoukqw(Setting::eiguikqsqiemumcm, 0)); } public function rsysgcucogueguuk() : array { return [Constants::qescuiwgsyuikume => $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->qcgakseyaikigqco($this->iooowgsqoyqseyuu()), Constants::ccggwaweegsyygga => RequestMultistep::symcgieuakksimmu()->yqqscekqmcgwkiao(), Constants::eqkeooqcsscoggia => $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->masoymaamekuykso($this->iooowgsqoyqseyuu(), true)]; } }
