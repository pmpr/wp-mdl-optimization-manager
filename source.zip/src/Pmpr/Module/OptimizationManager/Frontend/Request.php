<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669eebb8a3e37             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Frontend; use Pmpr\Common\Foundation\Frontend\Page; use Pmpr\Module\OptimizationManager\Setting; class Request extends Page { public function qiccuiwooiquycsg() { $this->wegcaymyqqoyewmw("\167\160\x2d\x73\160\x65\145\x64\55\162\145\161\165\145\x73\x74")->sqemekeuykmooums()->gswweykyogmsyawy(__("\x4f\x70\164\x69\155\x69\172\141\x74\151\157\156\40\x4d\157\144\165\x6c\145\40\122\145\x71\165\x65\163\x74\40\120\141\147\145", PR__MDL__OPTIMIZATION_MANAGER))->wmsaakuicamguoam((int) Setting::symcgieuakksimmu()->giiuwsmyumqwwiyq(Setting::eiguikqsqiemumcm, 0)); } public function aosyekoskegecumg($amakmumgguksgmum) { parent::aosyekoskegecumg($amakmumgguksgmum); } public function rsysgcucogueguuk() : array { return [self::qescuiwgsyuikume => $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->qcgakseyaikigqco($this->iooowgsqoyqseyuu()), self::ccggwaweegsyygga => RequestMultistep::symcgieuakksimmu()->yqqscekqmcgwkiao(), self::eqkeooqcsscoggia => $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->masoymaamekuykso($this->iooowgsqoyqseyuu(), true)]; } }
