<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f7d886db9c4             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Frontend; use Pmpr\Common\Foundation\Frontend\Page; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\OptimizationManager\Setting; class Request extends Page { public function qiccuiwooiquycsg() { $this->wegcaymyqqoyewmw("\167\160\55\x73\160\x65\145\x64\55\x72\145\161\x75\x65\x73\x74")->sqemekeuykmooums()->gswweykyogmsyawy(__("\x4f\x70\x74\151\155\151\x7a\x61\164\x69\x6f\156\x20\x4d\157\x64\x75\x6c\x65\x20\x52\145\161\x75\145\163\x74\40\120\141\x67\x65", PR__MDL__OPTIMIZATION_MANAGER))->wmsaakuicamguoam((int) Setting::symcgieuakksimmu()->giiuwsmyumqwwiyq(Setting::eiguikqsqiemumcm, 0)); } public function rsysgcucogueguuk() : array { return [Constants::qescuiwgsyuikume => $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->qcgakseyaikigqco($this->iooowgsqoyqseyuu()), Constants::ccggwaweegsyygga => RequestMultistep::symcgieuakksimmu()->yqqscekqmcgwkiao(), Constants::eqkeooqcsscoggia => $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->masoymaamekuykso($this->iooowgsqoyqseyuu(), true)]; } }
