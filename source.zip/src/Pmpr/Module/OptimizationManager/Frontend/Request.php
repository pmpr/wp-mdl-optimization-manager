<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc5806a0ec             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Frontend; use Pmpr\Common\Foundation\Frontend\Page; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\OptimizationManager\Setting; class Request extends Page { public function qiccuiwooiquycsg() { $this->wegcaymyqqoyewmw("\167\x70\55\x73\x70\x65\x65\144\55\162\x65\161\x75\145\163\x74")->sqemekeuykmooums()->gswweykyogmsyawy(__("\x4f\160\164\151\x6d\151\172\x61\164\151\x6f\156\x20\x4d\x6f\144\165\x6c\x65\40\x52\x65\161\165\145\163\164\40\x50\x61\147\x65", PR__MDL__OPTIMIZATION_MANAGER))->wmsaakuicamguoam($this->weysguygiseoukqw(Setting::eiguikqsqiemumcm, 0)); } public function rsysgcucogueguuk() : array { return [Constants::qescuiwgsyuikume => $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->qcgakseyaikigqco($this->iooowgsqoyqseyuu()), Constants::ccggwaweegsyygga => RequestMultistep::symcgieuakksimmu()->yqqscekqmcgwkiao(), Constants::eqkeooqcsscoggia => $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->masoymaamekuykso($this->iooowgsqoyqseyuu(), true)]; } }
