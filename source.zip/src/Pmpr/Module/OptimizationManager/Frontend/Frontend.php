<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ab90b7db1ad             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Frontend; use Pmpr\Module\OptimizationManager\Container; class Frontend extends Container { public function mameiwsayuyquoeq() { Request::symcgieuakksimmu(); RequestMultistep::symcgieuakksimmu(); } }
