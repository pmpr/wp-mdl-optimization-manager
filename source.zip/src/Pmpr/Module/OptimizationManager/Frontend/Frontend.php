<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66aeb5d2abe77             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Frontend; use Pmpr\Module\OptimizationManager\Container; class Frontend extends Container { public function mameiwsayuyquoeq() { Request::symcgieuakksimmu(); RequestMultistep::symcgieuakksimmu(); } }
