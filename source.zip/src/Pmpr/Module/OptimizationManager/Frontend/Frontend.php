<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb56e3d281a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Frontend; use Pmpr\Module\OptimizationManager\Container; class Frontend extends Container { public function mameiwsayuyquoeq() { Request::symcgieuakksimmu(); WPSpeed::symcgieuakksimmu(); RequestMultistep::symcgieuakksimmu(); } }
