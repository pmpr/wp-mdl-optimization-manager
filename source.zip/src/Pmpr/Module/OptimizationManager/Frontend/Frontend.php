<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66c31d588b892             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Frontend; use Pmpr\Module\OptimizationManager\Container; class Frontend extends Container { public function mameiwsayuyquoeq() { Request::symcgieuakksimmu(); WPSpeed::symcgieuakksimmu(); RequestMultistep::symcgieuakksimmu(); } }
