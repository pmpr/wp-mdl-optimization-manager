<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66b6188ad9125             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Frontend; use Pmpr\Module\OptimizationManager\Container; class Frontend extends Container { public function mameiwsayuyquoeq() { Request::symcgieuakksimmu(); RequestMultistep::symcgieuakksimmu(); } }
