<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669eebb8a3e37             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Frontend; use Pmpr\Module\ComponentManager\Frontend\InstallRequestMultistep; use Pmpr\Module\OptimizationManager\Setting; class RequestMultistep extends InstallRequestMultistep { public function __construct() { $this->swqsasqieqqgusew(Request::symcgieuakksimmu()); $this->componentID = Setting::symcgieuakksimmu()->giiuwsmyumqwwiyq(self::ocwsuwyiiasigqaa, 0); parent::__construct(); } }
