<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc5806a0ec             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Frontend; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\ComponentManager\Frontend\InstallRequestMultistep; use Pmpr\Module\OptimizationManager\Setting; class RequestMultistep extends InstallRequestMultistep { public function __construct() { $this->swqsasqieqqgusew(Request::symcgieuakksimmu()); $this->componentID = $this->weysguygiseoukqw(Constants::ocwsuwyiiasigqaa, 0); parent::__construct(); } }
