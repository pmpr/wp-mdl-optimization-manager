<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66868667851c5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Admin; use Pmpr\Common\Foundation\Woocommerce\ListTable\ProductCustomer; use Pmpr\Module\OptimizationManager\Setting; class CustomerList extends ProductCustomer { public function __construct($ywmkwiwkosakssii = []) { $this->product = Setting::eiwcuqigayigimak(Setting::oguseymmyyoyaako, 0); parent::__construct($ywmkwiwkosakssii); } }
