<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fa77c22e0ce             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Admin; use Pmpr\Common\Cover\Woocommerce\ListTable\ProductCustomer; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\OptimizationManager\Setting; class CustomerList extends ProductCustomer { public function __construct($ywmkwiwkosakssii = []) { $this->product = Setting::symcgieuakksimmu()->giiuwsmyumqwwiyq(Constants::oguseymmyyoyaako, 0); parent::__construct($ywmkwiwkosakssii); } }
