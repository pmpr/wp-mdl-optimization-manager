<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ec7b60a5c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Admin; use Pmpr\Common\Foundation\Page\Admin\Page; class Customer extends Page { const wuowaiyouwecckaw = "\x6f\x70\x74\x69\155\x69\x7a\141\x74\151\157\x6e\x5f\x63\165\x73\164\157\155\x65\x72\163"; public function __construct() { $wksoawcgagcgoask = $this->akuociswqmoigkas(); $this->args = ["\x70\x61\x72\145\x6e\164\137\163\154\165\147" => $wksoawcgagcgoask, "\160\141\x67\145\137\x74\151\x74\x6c\x65" => __("\103\x75\163\164\157\155\145\162\x73", PR__MDL__OPTIMIZATION_MANAGER), "\155\145\156\x75\x5f\163\x6c\x75\x67" => self::wuowaiyouwecckaw, "\160\157\163\x69\164\x69\x6f\x6e" => 0]; parent::__construct(); } public function suicksywcwiggasc() { $this->listTable = new CustomerList(); $this->waeasakssissiuqg()->prepare_items(); parent::suicksywcwiggasc(); } }
