<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669c38b3da912             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Admin; use Pmpr\Common\Foundation\Page\Admin\Page; class Customer extends Page { const wuowaiyouwecckaw = "\157\x70\164\x69\x6d\151\x7a\x61\x74\x69\x6f\x6e\x5f\x63\x75\163\164\157\155\x65\162\x73"; public function __construct() { $wksoawcgagcgoask = self::akuociswqmoigkas(); $this->args = ["\x70\x61\162\x65\156\164\x5f\x73\154\165\x67" => $wksoawcgagcgoask, "\x70\x61\x67\x65\137\x74\151\164\x6c\x65" => __("\x43\x75\163\x74\x6f\x6d\145\162\163", PR__MDL__OPTIMIZATION_MANAGER), "\x6d\x65\x6e\165\137\163\x6c\165\x67" => self::wuowaiyouwecckaw, "\x70\x6f\163\151\164\x69\157\x6e" => 0]; parent::__construct(); } public function suicksywcwiggasc() { $this->listTable = new CustomerList(); $this->waeasakssissiuqg()->prepare_items(); parent::suicksywcwiggasc(); } }
