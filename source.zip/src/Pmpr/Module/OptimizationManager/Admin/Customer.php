<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66c31d588b892             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Admin; use Pmpr\Common\Foundation\Page\Admin\Page; class Customer extends Page { const wuowaiyouwecckaw = "\x6f\160\x74\151\155\x69\172\x61\164\x69\x6f\156\x5f\143\x75\x73\x74\x6f\155\145\162\163"; public function __construct() { $wksoawcgagcgoask = self::akuociswqmoigkas(); $this->args = ["\x70\x61\x72\x65\156\164\x5f\163\x6c\x75\x67" => $wksoawcgagcgoask, "\x70\x61\x67\145\x5f\164\151\164\x6c\x65" => __("\103\165\x73\x74\157\155\x65\x72\x73", PR__MDL__OPTIMIZATION_MANAGER), "\155\145\156\x75\x5f\163\154\x75\x67" => self::wuowaiyouwecckaw, "\x70\x6f\x73\x69\164\x69\157\x6e" => 0]; parent::__construct(); } public function suicksywcwiggasc() { $this->listTable = new CustomerList(); $this->waeasakssissiuqg()->prepare_items(); parent::suicksywcwiggasc(); } }
