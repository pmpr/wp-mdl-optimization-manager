<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a2f4544fcb3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Admin; use Pmpr\Common\Foundation\Page\Admin\Page; class Customer extends Page { const wuowaiyouwecckaw = "\157\160\x74\151\155\x69\172\141\x74\151\x6f\156\x5f\143\x75\163\164\157\155\145\x72\163"; public function __construct() { $wksoawcgagcgoask = self::akuociswqmoigkas(); $this->args = ["\160\x61\x72\x65\156\164\x5f\163\154\165\147" => $wksoawcgagcgoask, "\160\x61\x67\145\137\164\151\164\x6c\x65" => __("\x43\x75\x73\x74\157\155\x65\162\x73", PR__MDL__OPTIMIZATION_MANAGER), "\155\x65\156\x75\137\163\x6c\x75\147" => self::wuowaiyouwecckaw, "\160\x6f\x73\x69\x74\x69\157\156" => 0]; parent::__construct(); } public function suicksywcwiggasc() { $this->listTable = new CustomerList(); $this->waeasakssissiuqg()->prepare_items(); parent::suicksywcwiggasc(); } }
