<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6687081b48ec2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Admin; use Pmpr\Common\Foundation\Page\Admin\Page; class Customer extends Page { const wuowaiyouwecckaw = "\x6f\x70\x74\x69\x6d\x69\172\x61\164\x69\x6f\156\137\143\165\x73\x74\x6f\155\145\x72\163"; public function __construct() { $wksoawcgagcgoask = self::akuociswqmoigkas(); $this->args = ["\x70\x61\x72\x65\156\x74\137\x73\154\165\147" => $wksoawcgagcgoask, "\x70\x61\x67\x65\137\164\x69\164\154\x65" => __("\103\165\163\164\x6f\x6d\x65\x72\163", PR__MDL__OPTIMIZATION_MANAGER), "\155\145\x6e\165\x5f\x73\154\x75\147" => self::wuowaiyouwecckaw, "\160\x6f\163\151\x74\x69\157\x6e" => 0]; parent::__construct(); } public function suicksywcwiggasc() { $this->listTable = new CustomerList(); $this->waeasakssissiuqg()->prepare_items(); parent::suicksywcwiggasc(); } }
