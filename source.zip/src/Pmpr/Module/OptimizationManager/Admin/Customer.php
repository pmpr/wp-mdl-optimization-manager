<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae90438cd4             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Admin; use Pmpr\Common\Foundation\Page\Admin\Page; class Customer extends Page { const wuowaiyouwecckaw = "\157\x70\164\x69\x6d\x69\172\x61\x74\x69\157\x6e\137\x63\x75\x73\x74\x6f\x6d\x65\x72\x73"; public function __construct() { $wksoawcgagcgoask = $this->akuociswqmoigkas(); $this->args = ["\160\x61\162\145\x6e\x74\137\163\154\165\147" => $wksoawcgagcgoask, "\x70\x61\x67\145\137\164\151\x74\x6c\145" => __("\103\x75\x73\164\x6f\155\145\162\x73", PR__MDL__OPTIMIZATION_MANAGER), "\x6d\145\x6e\165\x5f\163\x6c\165\147" => self::wuowaiyouwecckaw, "\160\157\x73\x69\x74\x69\157\156" => 0]; parent::__construct(); } public function suicksywcwiggasc() { $this->listTable = new CustomerList(); $this->waeasakssissiuqg()->prepare_items(); parent::suicksywcwiggasc(); } }
