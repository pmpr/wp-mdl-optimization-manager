<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ab90b7db1ad             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Admin; use Pmpr\Common\Foundation\Page\Admin\Page; class Customer extends Page { const wuowaiyouwecckaw = "\x6f\x70\x74\151\155\x69\172\141\x74\151\157\x6e\137\x63\165\163\x74\157\x6d\x65\162\163"; public function __construct() { $wksoawcgagcgoask = self::akuociswqmoigkas(); $this->args = ["\x70\141\x72\x65\x6e\x74\137\163\x6c\165\147" => $wksoawcgagcgoask, "\x70\x61\x67\x65\137\x74\151\x74\154\145" => __("\103\x75\x73\x74\157\x6d\x65\162\163", PR__MDL__OPTIMIZATION_MANAGER), "\155\145\x6e\165\137\163\x6c\x75\147" => self::wuowaiyouwecckaw, "\x70\157\x73\151\x74\151\157\x6e" => 0]; parent::__construct(); } public function suicksywcwiggasc() { $this->listTable = new CustomerList(); $this->waeasakssissiuqg()->prepare_items(); parent::suicksywcwiggasc(); } }
