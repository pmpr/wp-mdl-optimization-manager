<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f7d63a82ae5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Admin; use Pmpr\Common\Foundation\Page\Admin\Page; class Customer extends Page { const wuowaiyouwecckaw = "\x6f\160\x74\x69\155\x69\172\x61\x74\151\x6f\x6e\137\143\x75\x73\164\x6f\x6d\x65\162\x73"; public function __construct() { $wksoawcgagcgoask = $this->akuociswqmoigkas(); $this->args = ["\160\141\162\145\x6e\164\137\x73\x6c\165\x67" => $wksoawcgagcgoask, "\x70\x61\147\145\x5f\164\x69\164\x6c\x65" => __("\x43\165\163\x74\x6f\x6d\145\x72\163", PR__MDL__OPTIMIZATION_MANAGER), "\155\145\x6e\165\x5f\163\x6c\x75\x67" => self::wuowaiyouwecckaw, "\160\x6f\163\151\164\x69\x6f\x6e" => 0]; parent::__construct(); } public function suicksywcwiggasc() { $this->listTable = new CustomerList(); $this->waeasakssissiuqg()->prepare_items(); parent::suicksywcwiggasc(); } }
