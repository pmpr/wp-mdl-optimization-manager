<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce11a36a4e1             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Admin; use Pmpr\Common\Foundation\Page\Admin\Page; class Customer extends Page { const wuowaiyouwecckaw = "\x6f\160\164\151\155\x69\172\x61\x74\151\157\x6e\x5f\143\x75\x73\164\157\x6d\145\162\x73"; public function __construct() { $wksoawcgagcgoask = $this->akuociswqmoigkas(); $this->args = ["\x70\141\x72\145\156\x74\x5f\163\154\x75\147" => $wksoawcgagcgoask, "\160\141\147\145\137\164\x69\164\154\145" => __("\x43\x75\x73\164\x6f\155\145\x72\163", PR__MDL__OPTIMIZATION_MANAGER), "\x6d\x65\x6e\165\137\x73\x6c\x75\x67" => self::wuowaiyouwecckaw, "\x70\157\x73\x69\x74\x69\157\156" => 0]; parent::__construct(); } public function suicksywcwiggasc() { $this->listTable = new CustomerList(); $this->waeasakssissiuqg()->prepare_items(); parent::suicksywcwiggasc(); } }
