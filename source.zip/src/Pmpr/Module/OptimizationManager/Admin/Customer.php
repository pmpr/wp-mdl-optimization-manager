<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668f1c0e6e17c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Admin; use Pmpr\Common\Foundation\Page\Admin\Page; class Customer extends Page { const wuowaiyouwecckaw = "\157\x70\x74\x69\155\x69\x7a\141\164\x69\157\x6e\x5f\143\165\163\x74\x6f\155\x65\162\163"; public function __construct() { $wksoawcgagcgoask = self::akuociswqmoigkas(); $this->args = ["\x70\141\162\145\156\x74\137\x73\x6c\165\x67" => $wksoawcgagcgoask, "\160\x61\147\x65\137\164\x69\164\x6c\145" => __("\x43\165\163\x74\157\155\x65\162\163", PR__MDL__OPTIMIZATION_MANAGER), "\155\x65\156\x75\x5f\x73\154\165\147" => self::wuowaiyouwecckaw, "\160\x6f\163\151\x74\151\x6f\156" => 0]; parent::__construct(); } public function suicksywcwiggasc() { $this->listTable = new CustomerList(); $this->waeasakssissiuqg()->prepare_items(); parent::suicksywcwiggasc(); } }
