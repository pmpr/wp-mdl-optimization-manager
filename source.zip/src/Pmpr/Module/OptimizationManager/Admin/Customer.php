<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66871ee971196             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Admin; use Pmpr\Common\Foundation\Page\Admin\Page; class Customer extends Page { const wuowaiyouwecckaw = "\157\x70\164\151\155\x69\x7a\141\164\151\x6f\156\x5f\x63\165\x73\x74\x6f\155\145\x72\x73"; public function __construct() { $wksoawcgagcgoask = self::akuociswqmoigkas(); $this->args = ["\x70\x61\162\x65\x6e\164\x5f\163\154\x75\147" => $wksoawcgagcgoask, "\160\x61\147\145\x5f\164\151\x74\154\x65" => __("\103\x75\163\164\157\x6d\145\162\163", PR__MDL__OPTIMIZATION_MANAGER), "\155\x65\156\x75\137\163\154\x75\x67" => self::wuowaiyouwecckaw, "\x70\x6f\x73\151\x74\x69\157\x6e" => 0]; parent::__construct(); } public function suicksywcwiggasc() { $this->listTable = new CustomerList(); $this->waeasakssissiuqg()->prepare_items(); parent::suicksywcwiggasc(); } }
