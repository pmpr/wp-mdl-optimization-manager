<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668682bdd9cf1             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Admin; use Pmpr\Common\Foundation\Page\Admin\Page; class Customer extends Page { const wuowaiyouwecckaw = "\157\160\164\x69\155\151\x7a\141\164\151\x6f\156\x5f\x63\x75\163\164\x6f\155\x65\162\x73"; public function __construct() { $wksoawcgagcgoask = self::akuociswqmoigkas(); $this->args = ["\160\141\x72\145\x6e\164\x5f\x73\154\165\x67" => $wksoawcgagcgoask, "\x70\x61\147\x65\137\x74\151\164\x6c\145" => __("\103\x75\x73\164\x6f\x6d\x65\162\163", PR__MDL__OPTIMIZATION_MANAGER), "\x6d\x65\156\165\x5f\x73\154\165\147" => self::wuowaiyouwecckaw, "\160\157\x73\151\164\x69\157\x6e" => 0]; parent::__construct(); } public function suicksywcwiggasc() { $this->listTable = new CustomerList(); $this->waeasakssissiuqg()->prepare_items(); parent::suicksywcwiggasc(); } }
