<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66868667851c5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Admin; use Pmpr\Common\Foundation\Page\Admin\Page; class Customer extends Page { const wuowaiyouwecckaw = "\x6f\x70\164\151\155\x69\172\x61\164\151\x6f\x6e\137\x63\165\x73\164\157\x6d\x65\162\163"; public function __construct() { $wksoawcgagcgoask = self::akuociswqmoigkas(); $this->args = ["\x70\x61\x72\145\x6e\164\x5f\x73\x6c\165\x67" => $wksoawcgagcgoask, "\x70\x61\147\x65\x5f\x74\x69\164\154\x65" => __("\103\x75\x73\164\157\155\145\162\163", PR__MDL__OPTIMIZATION_MANAGER), "\x6d\145\x6e\x75\137\x73\154\165\147" => self::wuowaiyouwecckaw, "\x70\157\163\x69\x74\x69\x6f\x6e" => 0]; parent::__construct(); } public function suicksywcwiggasc() { $this->listTable = new CustomerList(); $this->waeasakssissiuqg()->prepare_items(); parent::suicksywcwiggasc(); } }
