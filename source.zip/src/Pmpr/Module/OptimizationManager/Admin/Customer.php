<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d1dbce6ff92             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Admin; use Pmpr\Common\Foundation\Page\Admin\Page; class Customer extends Page { const wuowaiyouwecckaw = "\x6f\160\164\151\155\151\172\141\164\x69\x6f\156\x5f\143\x75\x73\164\157\x6d\x65\162\x73"; public function __construct() { $wksoawcgagcgoask = $this->akuociswqmoigkas(); $this->args = ["\160\141\162\145\156\x74\x5f\x73\x6c\165\x67" => $wksoawcgagcgoask, "\160\x61\147\x65\137\x74\x69\x74\154\x65" => __("\x43\x75\163\x74\157\x6d\x65\x72\163", PR__MDL__OPTIMIZATION_MANAGER), "\155\x65\x6e\x75\x5f\x73\154\165\x67" => self::wuowaiyouwecckaw, "\160\x6f\163\x69\x74\x69\x6f\156" => 0]; parent::__construct(); } public function suicksywcwiggasc() { $this->listTable = new CustomerList(); $this->waeasakssissiuqg()->prepare_items(); parent::suicksywcwiggasc(); } }
