<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66788387d2261             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Admin; use Pmpr\Common\Foundation\Page\Admin\Page; class Customer extends Page { const wuowaiyouwecckaw = "\x6f\160\164\151\155\x69\x7a\x61\x74\151\x6f\x6e\137\143\165\163\164\x6f\155\x65\x72\163"; public function __construct() { $wksoawcgagcgoask = self::akuociswqmoigkas(); $this->args = ["\160\x61\x72\145\156\164\x5f\163\x6c\165\147" => $wksoawcgagcgoask, "\x70\141\147\145\x5f\x74\x69\x74\x6c\145" => __("\x43\x75\x73\164\x6f\x6d\x65\x72\163", PR__MDL__OPTIMIZATION_MANAGER), "\x6d\x65\156\165\137\x73\x6c\x75\147" => self::wuowaiyouwecckaw, "\x70\157\x73\151\x74\151\x6f\x6e" => 0]; parent::__construct(); } public function suicksywcwiggasc() { $this->listTable = new CustomerList(); $this->waeasakssissiuqg()->prepare_items(); parent::suicksywcwiggasc(); } }
