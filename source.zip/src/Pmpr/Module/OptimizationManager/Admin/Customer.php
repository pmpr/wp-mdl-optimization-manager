<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fa77c22e0ce             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Admin; use Pmpr\Common\Foundation\Page\Admin\Page; class Customer extends Page { const wuowaiyouwecckaw = "\x6f\x70\164\x69\155\x69\172\x61\164\151\x6f\x6e\x5f\143\165\163\164\157\x6d\x65\162\x73"; public function __construct() { $wksoawcgagcgoask = $this->akuociswqmoigkas(); $this->args = ["\160\141\x72\x65\x6e\x74\137\x73\x6c\165\147" => $wksoawcgagcgoask, "\160\x61\147\x65\137\164\151\x74\154\145" => __("\103\165\x73\x74\157\x6d\145\x72\x73", PR__MDL__OPTIMIZATION_MANAGER), "\155\145\x6e\165\x5f\x73\154\165\147" => self::wuowaiyouwecckaw, "\x70\x6f\x73\151\x74\151\x6f\x6e" => 0]; parent::__construct(); } public function suicksywcwiggasc() { $this->listTable = new CustomerList(); $this->waeasakssissiuqg()->prepare_items(); parent::suicksywcwiggasc(); } }
