<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb56e3d281a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Admin; use Pmpr\Common\Foundation\Page\Admin\Page; class Customer extends Page { const wuowaiyouwecckaw = "\157\x70\164\x69\155\x69\172\141\x74\151\157\x6e\137\143\165\x73\164\x6f\x6d\145\x72\163"; public function __construct() { $wksoawcgagcgoask = self::akuociswqmoigkas(); $this->args = ["\160\141\x72\145\x6e\x74\137\163\x6c\165\147" => $wksoawcgagcgoask, "\x70\141\147\x65\x5f\x74\151\164\154\x65" => __("\x43\165\163\164\x6f\x6d\x65\x72\x73", PR__MDL__OPTIMIZATION_MANAGER), "\155\145\156\165\x5f\x73\x6c\165\147" => self::wuowaiyouwecckaw, "\x70\x6f\163\151\x74\151\x6f\x6e" => 0]; parent::__construct(); } public function suicksywcwiggasc() { $this->listTable = new CustomerList(); $this->waeasakssissiuqg()->prepare_items(); parent::suicksywcwiggasc(); } }
