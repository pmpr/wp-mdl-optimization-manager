<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66aeb5d2abe77             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Admin; use Pmpr\Common\Foundation\Page\Admin\Page; class Customer extends Page { const wuowaiyouwecckaw = "\x6f\x70\x74\x69\x6d\x69\172\x61\164\151\157\x6e\x5f\143\165\x73\164\157\x6d\145\162\163"; public function __construct() { $wksoawcgagcgoask = self::akuociswqmoigkas(); $this->args = ["\x70\141\x72\x65\x6e\164\x5f\163\154\165\147" => $wksoawcgagcgoask, "\x70\141\x67\x65\x5f\164\x69\164\154\145" => __("\x43\x75\163\x74\157\x6d\145\x72\163", PR__MDL__OPTIMIZATION_MANAGER), "\155\145\156\x75\137\x73\x6c\165\x67" => self::wuowaiyouwecckaw, "\160\x6f\163\x69\x74\151\157\156" => 0]; parent::__construct(); } public function suicksywcwiggasc() { $this->listTable = new CustomerList(); $this->waeasakssissiuqg()->prepare_items(); parent::suicksywcwiggasc(); } }
