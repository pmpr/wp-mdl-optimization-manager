<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669ada84df097             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Admin; use Pmpr\Common\Foundation\Page\Admin\Page; class Customer extends Page { const wuowaiyouwecckaw = "\157\x70\x74\x69\155\x69\x7a\141\164\151\x6f\156\x5f\143\165\x73\x74\x6f\155\x65\162\163"; public function __construct() { $wksoawcgagcgoask = self::akuociswqmoigkas(); $this->args = ["\160\x61\162\x65\x6e\164\137\x73\x6c\x75\x67" => $wksoawcgagcgoask, "\160\141\147\145\137\164\151\x74\x6c\145" => __("\103\165\163\x74\157\x6d\145\162\163", PR__MDL__OPTIMIZATION_MANAGER), "\155\145\x6e\165\x5f\x73\154\165\147" => self::wuowaiyouwecckaw, "\160\x6f\x73\x69\x74\151\x6f\x6e" => 0]; parent::__construct(); } public function suicksywcwiggasc() { $this->listTable = new CustomerList(); $this->waeasakssissiuqg()->prepare_items(); parent::suicksywcwiggasc(); } }
