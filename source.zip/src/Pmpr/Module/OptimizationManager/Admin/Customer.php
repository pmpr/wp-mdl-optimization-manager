<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668daba42442f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Admin; use Pmpr\Common\Foundation\Page\Admin\Page; class Customer extends Page { const wuowaiyouwecckaw = "\x6f\x70\164\151\155\x69\172\141\164\x69\x6f\x6e\137\x63\x75\x73\164\x6f\155\145\162\x73"; public function __construct() { $wksoawcgagcgoask = self::akuociswqmoigkas(); $this->args = ["\160\141\x72\x65\156\x74\137\163\x6c\x75\x67" => $wksoawcgagcgoask, "\x70\141\x67\x65\137\x74\151\164\154\x65" => __("\103\x75\x73\164\157\155\x65\x72\x73", PR__MDL__OPTIMIZATION_MANAGER), "\x6d\145\156\165\137\x73\x6c\165\147" => self::wuowaiyouwecckaw, "\x70\157\163\x69\164\151\x6f\156" => 0]; parent::__construct(); } public function suicksywcwiggasc() { $this->listTable = new CustomerList(); $this->waeasakssissiuqg()->prepare_items(); parent::suicksywcwiggasc(); } }
