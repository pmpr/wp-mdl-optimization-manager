<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ced3502c13c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Admin; use Pmpr\Common\Foundation\Page\Admin\Page; class Customer extends Page { const wuowaiyouwecckaw = "\x6f\x70\x74\x69\x6d\x69\x7a\x61\x74\x69\157\156\x5f\x63\x75\163\x74\157\155\145\162\163"; public function __construct() { $wksoawcgagcgoask = $this->akuociswqmoigkas(); $this->args = ["\x70\x61\x72\145\156\x74\137\x73\x6c\x75\147" => $wksoawcgagcgoask, "\160\141\x67\x65\x5f\164\x69\x74\x6c\145" => __("\103\x75\163\164\x6f\x6d\x65\x72\163", PR__MDL__OPTIMIZATION_MANAGER), "\x6d\145\156\165\x5f\163\x6c\165\x67" => self::wuowaiyouwecckaw, "\160\x6f\x73\x69\x74\151\157\156" => 0]; parent::__construct(); } public function suicksywcwiggasc() { $this->listTable = new CustomerList(); $this->waeasakssissiuqg()->prepare_items(); parent::suicksywcwiggasc(); } }
