<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f6b052f0c6a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Admin; use Pmpr\Common\Foundation\Page\Admin\Page; class Customer extends Page { const wuowaiyouwecckaw = "\x6f\160\x74\x69\x6d\151\172\141\x74\151\x6f\x6e\137\x63\165\163\164\x6f\155\145\x72\163"; public function __construct() { $wksoawcgagcgoask = $this->akuociswqmoigkas(); $this->args = ["\x70\141\162\x65\156\164\x5f\163\154\x75\147" => $wksoawcgagcgoask, "\x70\x61\x67\x65\137\164\151\164\x6c\145" => __("\x43\x75\163\x74\157\x6d\x65\x72\x73", PR__MDL__OPTIMIZATION_MANAGER), "\x6d\145\x6e\x75\x5f\x73\x6c\165\147" => self::wuowaiyouwecckaw, "\160\x6f\163\151\x74\151\157\x6e" => 0]; parent::__construct(); } public function suicksywcwiggasc() { $this->listTable = new CustomerList(); $this->waeasakssissiuqg()->prepare_items(); parent::suicksywcwiggasc(); } }
