<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e41be607e2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Admin; use Pmpr\Common\Foundation\Page\Admin\Page; class Customer extends Page { const wuowaiyouwecckaw = "\x6f\x70\164\x69\155\x69\172\x61\x74\x69\157\156\x5f\x63\165\x73\164\157\155\145\x72\x73"; public function __construct() { $wksoawcgagcgoask = self::akuociswqmoigkas(); $this->args = ["\x70\x61\x72\145\x6e\x74\x5f\x73\154\165\x67" => $wksoawcgagcgoask, "\160\141\x67\x65\137\x74\x69\164\x6c\145" => __("\103\x75\x73\x74\157\155\145\162\163", PR__MDL__OPTIMIZATION_MANAGER), "\155\x65\156\x75\137\163\154\165\x67" => self::wuowaiyouwecckaw, "\160\x6f\x73\151\164\x69\x6f\156" => 0]; parent::__construct(); } public function suicksywcwiggasc() { $this->listTable = new CustomerList(); $this->waeasakssissiuqg()->prepare_items(); parent::suicksywcwiggasc(); } }
