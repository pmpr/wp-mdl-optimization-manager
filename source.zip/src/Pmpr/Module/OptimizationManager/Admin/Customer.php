<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668107472aaf4             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Admin; use Pmpr\Common\Foundation\Page\Admin\Page; class Customer extends Page { const wuowaiyouwecckaw = "\157\x70\164\151\155\x69\172\141\164\151\x6f\156\137\143\165\163\164\157\x6d\145\162\163"; public function __construct() { $wksoawcgagcgoask = self::akuociswqmoigkas(); $this->args = ["\160\x61\162\x65\x6e\164\x5f\x73\x6c\x75\x67" => $wksoawcgagcgoask, "\x70\141\x67\145\x5f\164\151\x74\x6c\145" => __("\x43\165\x73\x74\x6f\x6d\x65\x72\x73", PR__MDL__OPTIMIZATION_MANAGER), "\155\145\x6e\x75\137\163\x6c\x75\x67" => self::wuowaiyouwecckaw, "\160\157\x73\151\x74\151\x6f\x6e" => 0]; parent::__construct(); } public function suicksywcwiggasc() { $this->listTable = new CustomerList(); $this->waeasakssissiuqg()->prepare_items(); parent::suicksywcwiggasc(); } }
