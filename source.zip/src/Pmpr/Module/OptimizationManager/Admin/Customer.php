<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6668a93c651c2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Admin; use Pmpr\Common\Foundation\Page\Admin\Page; class Customer extends Page { const wuowaiyouwecckaw = "\157\x70\164\151\155\x69\x7a\x61\164\151\x6f\156\137\143\x75\x73\164\x6f\155\x65\x72\163"; public function __construct() { $wksoawcgagcgoask = self::akuociswqmoigkas(); $this->args = ["\x70\141\x72\145\156\x74\137\x73\x6c\x75\x67" => $wksoawcgagcgoask, "\160\141\147\145\x5f\164\151\x74\154\145" => __("\103\x75\x73\x74\157\155\145\x72\163", PR__MDL__OPTIMIZATION_MANAGER), "\155\145\x6e\165\x5f\163\154\165\x67" => self::wuowaiyouwecckaw, "\160\157\163\x69\164\x69\157\x6e" => 0]; parent::__construct(); } public function suicksywcwiggasc() { $this->listTable = new CustomerList(); $this->waeasakssissiuqg()->prepare_items(); parent::suicksywcwiggasc(); } }
