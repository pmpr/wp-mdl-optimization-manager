<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6688fb4047973             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Admin; use Pmpr\Common\Foundation\Page\Admin\Page; class Customer extends Page { const wuowaiyouwecckaw = "\157\160\x74\151\155\151\x7a\x61\x74\151\157\x6e\x5f\x63\165\x73\x74\x6f\x6d\x65\162\x73"; public function __construct() { $wksoawcgagcgoask = self::akuociswqmoigkas(); $this->args = ["\x70\x61\x72\x65\x6e\164\x5f\163\x6c\x75\x67" => $wksoawcgagcgoask, "\x70\x61\x67\x65\x5f\x74\x69\x74\x6c\145" => __("\x43\x75\x73\164\157\x6d\145\x72\163", PR__MDL__OPTIMIZATION_MANAGER), "\x6d\x65\156\165\137\x73\x6c\x75\x67" => self::wuowaiyouwecckaw, "\x70\x6f\x73\x69\x74\x69\x6f\156" => 0]; parent::__construct(); } public function suicksywcwiggasc() { $this->listTable = new CustomerList(); $this->waeasakssissiuqg()->prepare_items(); parent::suicksywcwiggasc(); } }
