<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668c5b679666b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Admin; use Pmpr\Common\Foundation\Page\Admin\Page; class Customer extends Page { const wuowaiyouwecckaw = "\x6f\x70\x74\151\x6d\151\x7a\141\x74\x69\x6f\156\137\x63\x75\163\x74\157\x6d\x65\162\x73"; public function __construct() { $wksoawcgagcgoask = self::akuociswqmoigkas(); $this->args = ["\160\141\162\x65\x6e\x74\137\x73\154\165\x67" => $wksoawcgagcgoask, "\x70\x61\147\x65\x5f\x74\x69\164\x6c\145" => __("\x43\x75\163\164\x6f\155\x65\162\163", PR__MDL__OPTIMIZATION_MANAGER), "\x6d\145\x6e\165\137\163\154\x75\x67" => self::wuowaiyouwecckaw, "\x70\x6f\163\x69\164\151\157\156" => 0]; parent::__construct(); } public function suicksywcwiggasc() { $this->listTable = new CustomerList(); $this->waeasakssissiuqg()->prepare_items(); parent::suicksywcwiggasc(); } }
