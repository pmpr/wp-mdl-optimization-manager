<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6606962cb6677             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Admin; use Pmpr\Common\Foundation\Page\Admin\Page; class Customer extends Page { const wuowaiyouwecckaw = "\x6f\x70\x74\x69\155\x69\172\x61\164\151\x6f\156\137\x63\x75\x73\164\157\155\145\x72\163"; public function __construct() { $wksoawcgagcgoask = self::akuociswqmoigkas(); $this->args = ["\160\x61\162\145\156\x74\x5f\x73\154\165\x67" => $wksoawcgagcgoask, "\160\x61\147\145\x5f\164\151\164\x6c\x65" => __("\103\x75\163\x74\157\x6d\x65\x72\163", PR__MDL__OPTIMIZATION_MANAGER), "\x6d\x65\x6e\165\137\163\154\165\x67" => self::wuowaiyouwecckaw, "\x70\157\x73\151\x74\x69\x6f\x6e" => 0]; parent::__construct(); } public function suicksywcwiggasc() { $this->listTable = new CustomerList(); $this->waeasakssissiuqg()->prepare_items(); parent::suicksywcwiggasc(); } }
