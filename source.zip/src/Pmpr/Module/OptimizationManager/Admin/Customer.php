<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66b6188ad9125             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Admin; use Pmpr\Common\Foundation\Page\Admin\Page; class Customer extends Page { const wuowaiyouwecckaw = "\x6f\x70\164\151\155\151\x7a\141\x74\151\x6f\x6e\137\143\x75\163\x74\157\155\x65\162\x73"; public function __construct() { $wksoawcgagcgoask = self::akuociswqmoigkas(); $this->args = ["\160\141\x72\145\156\x74\137\x73\154\x75\147" => $wksoawcgagcgoask, "\160\141\147\x65\137\x74\151\164\x6c\145" => __("\x43\165\x73\164\157\x6d\145\x72\163", PR__MDL__OPTIMIZATION_MANAGER), "\155\x65\x6e\x75\x5f\163\154\x75\147" => self::wuowaiyouwecckaw, "\160\x6f\x73\x69\164\x69\x6f\x6e" => 0]; parent::__construct(); } public function suicksywcwiggasc() { $this->listTable = new CustomerList(); $this->waeasakssissiuqg()->prepare_items(); parent::suicksywcwiggasc(); } }
