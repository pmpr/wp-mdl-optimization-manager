<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a8912ac32             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Admin; use Pmpr\Common\Foundation\Page\Admin\Page; class Customer extends Page { const wuowaiyouwecckaw = "\x6f\x70\164\x69\155\151\x7a\x61\x74\151\x6f\156\x5f\x63\165\163\x74\157\155\145\x72\163"; public function __construct() { $wksoawcgagcgoask = self::akuociswqmoigkas(); $this->args = ["\160\141\162\145\x6e\164\137\x73\x6c\x75\147" => $wksoawcgagcgoask, "\x70\x61\x67\145\x5f\164\151\x74\x6c\x65" => __("\x43\165\163\164\x6f\x6d\145\162\163", PR__MDL__OPTIMIZATION_MANAGER), "\x6d\145\x6e\x75\137\x73\x6c\x75\147" => self::wuowaiyouwecckaw, "\160\x6f\163\x69\x74\x69\x6f\156" => 0]; parent::__construct(); } public function suicksywcwiggasc() { $this->listTable = new CustomerList(); $this->waeasakssissiuqg()->prepare_items(); parent::suicksywcwiggasc(); } }
