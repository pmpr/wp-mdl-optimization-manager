<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ced74e1cb27             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Admin; use Pmpr\Common\Foundation\Page\Admin\Page; class Customer extends Page { const wuowaiyouwecckaw = "\x6f\x70\164\151\155\151\x7a\141\164\151\157\156\x5f\143\165\163\164\157\x6d\x65\162\163"; public function __construct() { $wksoawcgagcgoask = $this->akuociswqmoigkas(); $this->args = ["\160\141\162\145\156\x74\137\x73\154\x75\147" => $wksoawcgagcgoask, "\160\x61\x67\145\x5f\164\x69\x74\154\x65" => __("\103\165\x73\164\157\x6d\145\162\x73", PR__MDL__OPTIMIZATION_MANAGER), "\x6d\145\x6e\165\x5f\163\x6c\165\147" => self::wuowaiyouwecckaw, "\x70\157\x73\x69\x74\x69\x6f\156" => 0]; parent::__construct(); } public function suicksywcwiggasc() { $this->listTable = new CustomerList(); $this->waeasakssissiuqg()->prepare_items(); parent::suicksywcwiggasc(); } }
