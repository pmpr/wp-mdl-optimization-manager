<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cf4bb6aeb36             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Admin; use Pmpr\Common\Foundation\Page\Admin\Page; class Customer extends Page { const wuowaiyouwecckaw = "\x6f\160\164\x69\x6d\151\x7a\141\164\151\157\156\137\x63\165\163\x74\157\x6d\x65\162\163"; public function __construct() { $wksoawcgagcgoask = $this->akuociswqmoigkas(); $this->args = ["\160\x61\162\x65\x6e\164\137\163\154\165\x67" => $wksoawcgagcgoask, "\160\x61\147\x65\x5f\x74\x69\164\x6c\145" => __("\103\x75\163\164\x6f\155\x65\x72\163", PR__MDL__OPTIMIZATION_MANAGER), "\x6d\145\156\165\137\163\154\x75\x67" => self::wuowaiyouwecckaw, "\x70\x6f\163\151\164\151\157\x6e" => 0]; parent::__construct(); } public function suicksywcwiggasc() { $this->listTable = new CustomerList(); $this->waeasakssissiuqg()->prepare_items(); parent::suicksywcwiggasc(); } }
