<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668400e7ecf4b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Admin; use Pmpr\Common\Foundation\Page\Admin\Page; class Customer extends Page { const wuowaiyouwecckaw = "\x6f\x70\x74\151\x6d\151\x7a\x61\164\151\x6f\156\137\143\x75\163\164\157\155\145\162\163"; public function __construct() { $wksoawcgagcgoask = self::akuociswqmoigkas(); $this->args = ["\160\141\162\x65\156\x74\x5f\x73\154\165\x67" => $wksoawcgagcgoask, "\160\141\147\x65\137\x74\x69\x74\x6c\x65" => __("\x43\x75\x73\164\x6f\x6d\x65\x72\x73", PR__MDL__OPTIMIZATION_MANAGER), "\x6d\145\156\x75\137\163\154\165\147" => self::wuowaiyouwecckaw, "\x70\157\x73\x69\164\x69\x6f\x6e" => 0]; parent::__construct(); } public function suicksywcwiggasc() { $this->listTable = new CustomerList(); $this->waeasakssissiuqg()->prepare_items(); parent::suicksywcwiggasc(); } }
