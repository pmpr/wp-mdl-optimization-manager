<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6687081b48ec2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Admin; class Admin extends Common { public function mameiwsayuyquoeq() { Customer::symcgieuakksimmu(); } }
