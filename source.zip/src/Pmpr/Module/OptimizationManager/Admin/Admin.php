<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669c38b3da912             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Admin; class Admin extends Common { public function mameiwsayuyquoeq() { Customer::symcgieuakksimmu(); } }
