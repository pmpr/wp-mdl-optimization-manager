<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668400e7ecf4b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Admin; class Admin extends Common { public function mameiwsayuyquoeq() { Customer::symcgieuakksimmu(); } }
