<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66788387d2261             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Admin; class Admin extends Common { public function mameiwsayuyquoeq() { Customer::symcgieuakksimmu(); } }
