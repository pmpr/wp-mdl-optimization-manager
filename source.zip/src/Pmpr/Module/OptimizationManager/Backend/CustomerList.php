<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc5806a0ec             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Backend; use Pmpr\Common\Cover\Woocommerce\ListTable\ProductCustomer; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\OptimizationManager\Setting; class CustomerList extends ProductCustomer { public function __construct($ywmkwiwkosakssii = []) { $this->product = Setting::symcgieuakksimmu()->giiuwsmyumqwwiyq(Constants::oguseymmyyoyaako, 0); parent::__construct($ywmkwiwkosakssii); } }
