<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66c508f028b24             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription; use Pmpr\Module\OptimizationManager\Container; use Pmpr\Module\OptimizationManager\Subscription\Interfaces\CommonInterface; abstract class Common extends Container implements CommonInterface { public function ikcgmcycisiccyuc() { $this->settingObj = Setting::symcgieuakksimmu(); } }
