<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ec7b60a5c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription; use Pmpr\Module\OptimizationManager\Container; abstract class Common extends Container { public function ikcgmcycisiccyuc() { $this->settingObj = Setting::symcgieuakksimmu(); } }
