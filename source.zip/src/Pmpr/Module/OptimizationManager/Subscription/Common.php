<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4b1aa24aa             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Setting; use Pmpr\Module\OptimizationManager\Container; abstract class Common extends Container { public function kmuweyayaqoeqiyw() : ?Setting { return Setting::symcgieuakksimmu(); } }
