<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb56e3d281a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription\Frontend; use Pmpr\Module\OptimizationManager\Subscription\Common; class Frontend extends Common { public function mameiwsayuyquoeq() { Pricing::symcgieuakksimmu(); PricingMultistep::symcgieuakksimmu(); } }
