<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668c5b679666b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription\Frontend; use Pmpr\Module\OptimizationManager\Subscription\Common; use Pmpr\Module\OptimizationManager\Subscription\Frontend\Page\Page; use Pmpr\Module\OptimizationManager\Subscription\Setting; class Frontend extends Common { public function mameiwsayuyquoeq() { Page::symcgieuakksimmu(); MultistepForm::symcgieuakksimmu(); } }
