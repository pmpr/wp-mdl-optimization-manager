<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f7d886db9c4             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription\Frontend; use Pmpr\Module\OptimizationManager\Subscription\Common; class Frontend extends Common { public function mameiwsayuyquoeq() { Pricing::symcgieuakksimmu(); PricingMultistep::symcgieuakksimmu(); } }
