<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66868667851c5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription\Frontend\Page; use Pmpr\Module\OptimizationManager\Subscription\Common; class Page extends Common { public function mameiwsayuyquoeq() { Pricing::symcgieuakksimmu(); } }
