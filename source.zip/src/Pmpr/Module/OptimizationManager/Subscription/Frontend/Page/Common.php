<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66788387d2261             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription\Frontend\Page; use Pmpr\Common\Foundation\Frontend\Page; abstract class Common extends Page { }
