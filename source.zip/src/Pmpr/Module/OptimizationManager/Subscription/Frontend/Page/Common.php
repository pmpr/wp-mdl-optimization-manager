<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6606962cb6677             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription\Frontend\Page; use Pmpr\Common\Foundation\Frontend\Page; abstract class Common extends Page { }
