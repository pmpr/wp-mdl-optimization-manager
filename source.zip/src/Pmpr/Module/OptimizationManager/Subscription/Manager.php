<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668daba42442f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription; class Manager extends Common { }
