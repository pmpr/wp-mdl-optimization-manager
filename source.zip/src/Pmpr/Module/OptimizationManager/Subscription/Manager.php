<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             680177152c08b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription; class Manager extends Common { }
