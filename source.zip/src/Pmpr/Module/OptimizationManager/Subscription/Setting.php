<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d86280bb1d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Subscription\Setting as BaseClass; use Pmpr\Module\OptimizationManager\Subscription\Traits\EngineTrait; class Setting extends BaseClass { use EngineTrait; public function qiccuiwooiquycsg() { parent::qiccuiwooiquycsg(); $this->id .= "\137\x73\165\x62"; $this->hasLicense = false; $this->title = __("\x53\165\142\163\x63\162\151\x70\x74\151\157\156\40\123\x65\164\164\x69\156\x67", PR__MDL__OPTIMIZATION_MANAGER); $this->igiywquyccyiaucw(Constants::ysgwugcqguggmigq, __("\x4f\160\x74\x69\x6d\151\172\141\x74\151\x6f\x6e\x20\x4d\141\156\141\x67\145\162\x20\123\165\x62\x73\x63\162\x69\x70\164\x69\x6f\156\x20\123\x65\x74\164\x69\x6e\x67", PR__MDL__OPTIMIZATION_MANAGER)); } }
