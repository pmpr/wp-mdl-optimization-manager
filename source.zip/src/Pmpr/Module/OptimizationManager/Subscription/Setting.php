<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6686f09d04cd6             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription; use Pmpr\Common\Subscription\Setting as BaseClass; use Pmpr\Module\OptimizationManager\Subscription\Traits\EngineTrait; class Setting extends BaseClass { use EngineTrait; public function qiccuiwooiquycsg() { parent::qiccuiwooiquycsg(); $this->id .= "\137\x73\x75\142"; $this->hasLicense = false; } public function wyyuauosmqoeucmg() { $this->igiywquyccyiaucw(self::qescuiwgsyuikume, __("\117\160\164\x69\x6d\x69\x7a\141\x74\x69\157\156\40\x4d\x61\156\x61\147\x65\162\x20\x53\165\142\x73\x63\x72\151\x70\x74\151\157\156\x20\x53\x65\x74\x74\x69\x6e\x67", PR__MDL__OPTIMIZATION_MANAGER))->igiywquyccyiaucw(self::qsegwakiwaiyimyy, __("\x53\x75\x62\x73\x63\162\151\x70\164\x69\x6f\x6e\x20\123\145\164\164\151\x6e\x67", PR__MDL__OPTIMIZATION_MANAGER)); } }
