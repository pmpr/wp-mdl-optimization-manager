<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668682bdd9cf1             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription; use Pmpr\Common\Subscription\Setting as BaseClass; use Pmpr\Module\OptimizationManager\Subscription\Traits\EngineTrait; class Setting extends BaseClass { use EngineTrait; public function qiccuiwooiquycsg() { parent::qiccuiwooiquycsg(); $this->id .= "\x5f\x73\x75\142"; $this->hasLicense = false; } public function wyyuauosmqoeucmg() { $this->igiywquyccyiaucw(self::qescuiwgsyuikume, __("\117\160\x74\151\x6d\151\172\x61\164\x69\157\156\40\115\141\156\141\147\x65\x72\x20\123\x75\x62\163\143\x72\151\x70\164\x69\157\156\40\123\x65\164\164\x69\x6e\x67", PR__MDL__OPTIMIZATION_MANAGER))->igiywquyccyiaucw(self::qsegwakiwaiyimyy, __("\x53\165\x62\163\x63\162\151\x70\x74\151\x6f\x6e\40\123\145\x74\x74\x69\156\147", PR__MDL__OPTIMIZATION_MANAGER)); } }
