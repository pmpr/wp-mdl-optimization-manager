<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668400e7ecf4b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription; use Pmpr\Common\Subscription\Setting as BaseClass; use Pmpr\Module\OptimizationManager\Subscription\Traits\EngineTrait; class Setting extends BaseClass { use EngineTrait; public function qiccuiwooiquycsg() { parent::qiccuiwooiquycsg(); $this->id .= "\137\163\x75\142"; $this->hasLicense = false; } public function wyyuauosmqoeucmg() { $this->igiywquyccyiaucw(self::qescuiwgsyuikume, __("\x4f\160\x74\x69\x6d\151\x7a\x61\164\x69\x6f\x6e\40\115\141\x6e\x61\147\x65\x72\x20\123\x75\142\x73\x63\x72\151\x70\164\x69\x6f\156\40\x53\145\164\164\x69\x6e\x67", PR__MDL__OPTIMIZATION_MANAGER))->igiywquyccyiaucw(self::qsegwakiwaiyimyy, __("\123\x75\x62\163\143\162\151\160\164\x69\157\156\40\123\x65\164\164\x69\x6e\x67", PR__MDL__OPTIMIZATION_MANAGER)); } }
