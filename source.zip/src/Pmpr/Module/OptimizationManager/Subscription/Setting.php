<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce11a36a4e1             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Subscription\Setting as BaseClass; use Pmpr\Module\OptimizationManager\Subscription\Traits\EngineTrait; class Setting extends BaseClass { use EngineTrait; public function qiccuiwooiquycsg() { parent::qiccuiwooiquycsg(); $this->id .= "\137\163\165\142"; $this->hasLicense = false; $this->title = __("\x4f\x70\164\151\x6d\151\x7a\x61\164\x69\157\156\40\x4d\141\x6e\x61\x67\x65\162\40\x53\165\x62\163\x63\162\151\x70\164\151\157\156\x20\123\145\x74\x74\x69\156\147", PR__MDL__OPTIMIZATION_MANAGER); $this->igiywquyccyiaucw(Constants::qsegwakiwaiyimyy, __("\x53\x75\x62\163\x63\x72\151\x70\164\151\x6f\156\40\x53\x65\x74\x74\x69\x6e\x67", PR__MDL__OPTIMIZATION_MANAGER)); } }
