<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66868667851c5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription; use Pmpr\Common\Subscription\Setting as BaseClass; use Pmpr\Module\OptimizationManager\Subscription\Traits\EngineTrait; class Setting extends BaseClass { use EngineTrait; public function qiccuiwooiquycsg() { parent::qiccuiwooiquycsg(); $this->id .= "\137\x73\165\x62"; $this->hasLicense = false; } public function wyyuauosmqoeucmg() { $this->igiywquyccyiaucw(self::qescuiwgsyuikume, __("\x4f\160\164\x69\155\x69\172\x61\164\x69\157\156\40\115\141\x6e\x61\147\145\x72\x20\x53\165\x62\x73\143\x72\x69\160\164\151\157\156\x20\x53\145\164\x74\x69\x6e\x67", PR__MDL__OPTIMIZATION_MANAGER))->igiywquyccyiaucw(self::qsegwakiwaiyimyy, __("\123\x75\x62\x73\143\162\151\x70\x74\151\157\x6e\40\x53\145\x74\x74\151\x6e\147", PR__MDL__OPTIMIZATION_MANAGER)); } }
