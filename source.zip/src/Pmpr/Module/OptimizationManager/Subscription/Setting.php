<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f6b052f0c6a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Subscription\Setting as BaseClass; use Pmpr\Module\OptimizationManager\Subscription\Traits\EngineTrait; class Setting extends BaseClass { use EngineTrait; public function qiccuiwooiquycsg() { parent::qiccuiwooiquycsg(); $this->id .= "\137\x73\165\x62"; $this->hasLicense = false; $this->title = __("\x53\x75\x62\x73\143\x72\x69\160\x74\151\x6f\x6e\40\123\145\164\x74\x69\156\x67", PR__MDL__OPTIMIZATION_MANAGER); $this->igiywquyccyiaucw(Constants::ysgwugcqguggmigq, __("\117\160\164\151\x6d\x69\172\141\x74\151\x6f\156\x20\115\141\x6e\x61\147\x65\162\40\123\165\x62\163\x63\162\151\160\164\151\157\x6e\40\123\x65\x74\x74\x69\x6e\147", PR__MDL__OPTIMIZATION_MANAGER)); } }
