<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb56e3d281a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription; use Pmpr\Common\Subscription\Setting as BaseClass; use Pmpr\Module\OptimizationManager\Subscription\Traits\EngineTrait; class Setting extends BaseClass { use EngineTrait; public function qiccuiwooiquycsg() { parent::qiccuiwooiquycsg(); $this->id .= "\137\x73\x75\142"; $this->hasLicense = false; $this->title = __("\x4f\160\164\151\155\x69\x7a\141\164\x69\157\x6e\x20\115\x61\x6e\141\147\145\x72\x20\123\x75\142\x73\x63\162\151\x70\164\x69\157\156\x20\123\145\x74\x74\151\156\147", PR__MDL__OPTIMIZATION_MANAGER); $this->igiywquyccyiaucw(self::qsegwakiwaiyimyy, __("\123\165\142\x73\x63\162\151\x70\x74\151\157\x6e\40\x53\145\164\x74\151\156\x67", PR__MDL__OPTIMIZATION_MANAGER)); } }
