<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669ada84df097             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription; use Pmpr\Common\Subscription\Setting as BaseClass; use Pmpr\Module\OptimizationManager\Subscription\Traits\EngineTrait; class Setting extends BaseClass { use EngineTrait; public function qiccuiwooiquycsg() { parent::qiccuiwooiquycsg(); $this->id .= "\x5f\x73\165\142"; $this->hasLicense = false; } public function wyyuauosmqoeucmg() { $this->igiywquyccyiaucw(self::qescuiwgsyuikume, __("\x4f\160\x74\151\155\151\172\x61\164\151\x6f\x6e\x20\115\141\156\x61\x67\x65\162\x20\123\x75\142\x73\143\162\x69\160\x74\151\x6f\x6e\40\123\x65\x74\x74\x69\156\147", PR__MDL__OPTIMIZATION_MANAGER))->igiywquyccyiaucw(self::qsegwakiwaiyimyy, __("\x53\x75\142\x73\x63\162\151\x70\164\151\157\x6e\40\123\145\x74\164\151\156\147", PR__MDL__OPTIMIZATION_MANAGER)); } }
