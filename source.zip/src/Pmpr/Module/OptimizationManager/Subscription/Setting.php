<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ab90b7db1ad             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription; use Pmpr\Common\Subscription\Setting as BaseClass; use Pmpr\Module\OptimizationManager\Subscription\Traits\EngineTrait; class Setting extends BaseClass { use EngineTrait; public function qiccuiwooiquycsg() { parent::qiccuiwooiquycsg(); $this->id .= "\x5f\163\165\142"; $this->hasLicense = false; } public function wyyuauosmqoeucmg() { $this->igiywquyccyiaucw(self::qescuiwgsyuikume, __("\117\160\164\x69\155\151\x7a\x61\164\x69\x6f\156\x20\115\x61\156\x61\x67\x65\162\40\123\165\142\163\143\162\151\x70\164\x69\157\156\40\x53\x65\x74\164\151\156\147", PR__MDL__OPTIMIZATION_MANAGER))->igiywquyccyiaucw(self::qsegwakiwaiyimyy, __("\123\165\x62\x73\143\x72\x69\160\164\x69\157\x6e\40\x53\x65\x74\164\x69\156\147", PR__MDL__OPTIMIZATION_MANAGER)); } }
