<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66aeb5d2abe77             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription; use Pmpr\Common\Subscription\Setting as BaseClass; use Pmpr\Module\OptimizationManager\Subscription\Traits\EngineTrait; class Setting extends BaseClass { use EngineTrait; public function qiccuiwooiquycsg() { parent::qiccuiwooiquycsg(); $this->id .= "\x5f\x73\x75\x62"; $this->hasLicense = false; } public function wyyuauosmqoeucmg() { $this->igiywquyccyiaucw(self::qescuiwgsyuikume, __("\x4f\160\x74\x69\x6d\x69\x7a\x61\164\151\x6f\156\x20\x4d\x61\156\x61\x67\x65\162\40\123\165\142\163\143\162\151\x70\164\151\x6f\156\40\123\x65\164\x74\x69\156\x67", PR__MDL__OPTIMIZATION_MANAGER))->igiywquyccyiaucw(self::qsegwakiwaiyimyy, __("\123\x75\x62\163\143\162\x69\x70\x74\x69\x6f\x6e\x20\x53\145\164\x74\x69\156\147", PR__MDL__OPTIMIZATION_MANAGER)); } }
