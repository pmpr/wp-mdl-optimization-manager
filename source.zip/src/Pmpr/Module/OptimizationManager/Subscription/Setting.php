<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d1dbce6ff92             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Subscription\Setting as BaseClass; use Pmpr\Module\OptimizationManager\Subscription\Traits\EngineTrait; class Setting extends BaseClass { use EngineTrait; public function qiccuiwooiquycsg() { parent::qiccuiwooiquycsg(); $this->id .= "\x5f\163\165\142"; $this->hasLicense = false; $this->title = __("\123\165\x62\163\x63\x72\151\x70\164\x69\157\156\40\123\x65\164\x74\151\156\147", PR__MDL__OPTIMIZATION_MANAGER); $this->igiywquyccyiaucw(Constants::ysgwugcqguggmigq, __("\x4f\x70\x74\151\155\151\x7a\141\164\x69\157\x6e\40\115\x61\x6e\x61\x67\145\x72\40\x53\x75\x62\x73\x63\x72\x69\x70\x74\151\157\156\x20\123\145\x74\164\151\156\x67", PR__MDL__OPTIMIZATION_MANAGER)); } }
