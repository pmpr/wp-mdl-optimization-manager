<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668107472aaf4             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription; use Pmpr\Common\Subscription\Setting as BaseClass; use Pmpr\Module\OptimizationManager\Subscription\Traits\EngineTrait; class Setting extends BaseClass { use EngineTrait; public function qiccuiwooiquycsg() { parent::qiccuiwooiquycsg(); $this->id .= "\x5f\x73\165\x62"; $this->hasLicense = false; } public function wyyuauosmqoeucmg() { $this->igiywquyccyiaucw(self::qescuiwgsyuikume, __("\117\x70\164\151\x6d\151\x7a\141\x74\x69\157\x6e\x20\x4d\x61\x6e\x61\147\x65\162\40\x53\165\142\163\143\162\x69\x70\164\151\x6f\x6e\x20\123\x65\164\164\151\x6e\x67", PR__MDL__OPTIMIZATION_MANAGER))->igiywquyccyiaucw(self::qsegwakiwaiyimyy, __("\x53\x75\142\x73\x63\162\151\x70\x74\x69\x6f\x6e\x20\x53\145\164\164\x69\156\x67", PR__MDL__OPTIMIZATION_MANAGER)); } }
