<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66c31d588b892             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription; use Pmpr\Common\Subscription\Setting as BaseClass; use Pmpr\Module\OptimizationManager\Subscription\Traits\EngineTrait; class Setting extends BaseClass { use EngineTrait; public function qiccuiwooiquycsg() { parent::qiccuiwooiquycsg(); $this->title = __("\x4f\160\164\x69\155\151\x7a\x61\x74\x69\157\156\x20\115\141\x6e\141\x67\145\162\40\x53\165\x62\163\143\x72\x69\x70\164\x69\x6f\x6e\x20\123\145\x74\164\x69\156\x67", PR__MDL__OPTIMIZATION_MANAGER); $this->igiywquyccyiaucw(self::qsegwakiwaiyimyy, __("\123\165\142\163\x63\x72\151\160\164\x69\x6f\x6e\40\x53\x65\x74\x74\x69\156\147", PR__MDL__OPTIMIZATION_MANAGER)); $this->id .= "\x5f\163\x75\142"; $this->hasLicense = false; } }
