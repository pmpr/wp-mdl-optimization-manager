<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b742e8482             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Subscription\Setting as BaseClass; use Pmpr\Module\OptimizationManager\Subscription\Traits\EngineTrait; class Setting extends BaseClass { use EngineTrait; public function qiccuiwooiquycsg() { parent::qiccuiwooiquycsg(); $this->id .= "\x5f\x73\165\142"; $this->hasLicense = false; $this->title = __("\123\165\142\x73\143\162\x69\x70\164\151\157\156\x20\x53\x65\x74\x74\151\156\147", PR__MDL__OPTIMIZATION_MANAGER); $this->igiywquyccyiaucw(Constants::ysgwugcqguggmigq, __("\117\x70\164\151\x6d\151\x7a\x61\164\x69\157\x6e\40\x4d\x61\x6e\141\147\145\162\x20\123\x75\x62\163\143\162\151\160\x74\151\157\x6e\40\123\x65\164\164\151\x6e\x67", PR__MDL__OPTIMIZATION_MANAGER)); } }
