<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d893b0a1ef             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Subscription\Setting as BaseClass; use Pmpr\Module\OptimizationManager\Subscription\Traits\EngineTrait; class Setting extends BaseClass { use EngineTrait; public function qiccuiwooiquycsg() { parent::qiccuiwooiquycsg(); $this->id .= "\137\163\x75\142"; $this->hasLicense = false; $this->title = __("\123\165\x62\x73\x63\162\151\160\164\x69\157\156\x20\x53\145\164\x74\151\x6e\147", PR__MDL__OPTIMIZATION_MANAGER); $this->igiywquyccyiaucw(Constants::ysgwugcqguggmigq, __("\117\160\x74\x69\x6d\151\x7a\141\164\151\x6f\156\x20\115\x61\x6e\141\147\x65\162\x20\x53\165\142\163\x63\x72\x69\x70\x74\x69\x6f\x6e\x20\x53\x65\164\x74\x69\156\147", PR__MDL__OPTIMIZATION_MANAGER)); } }
