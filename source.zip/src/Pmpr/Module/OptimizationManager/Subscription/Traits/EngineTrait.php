<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668f1c0e6e17c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription\Traits; use Pmpr\Module\OptimizationManager\Subscription\Engine; trait EngineTrait { protected ?Engine $engine = null; public function uykissogmuaaocsg() : Engine { if ($this->engine) { goto qogqewiwmwiwskgm; } $this->engine = Engine::symcgieuakksimmu(); qogqewiwmwiwskgm: return $this->engine; } }
