<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ab90b7db1ad             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription\Traits; use Pmpr\Module\OptimizationManager\Subscription\Engine; trait EngineTrait { protected ?Engine $engine = null; public function uykissogmuaaocsg() : Engine { if ($this->engine) { goto yqykqysmiquwoasu; } $this->engine = Engine::symcgieuakksimmu(); yqykqysmiquwoasu: return $this->engine; } }
