<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f7d63a82ae5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription\Traits; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\DomainManager\Model\Domain; trait AbstractSubTrait { public function yseaccyokaeameou($qamwkmomamooqqic) { return $this->caokeucsksukesyo()->wmkogisswkckmeua()->ywggokoaagwwqyak([Constants::squoamkioomemiyi => Constants::emkkgysokckswycs, Constants::emkkgysokckswycs => Domain::symcgieuakksimmu(), Constants::ckmqoekmugkggeym => $qamwkmomamooqqic]); } public function ogkiouuqqmaagscs($qamwkmomamooqqic) : string { $pkyyagewkiyckmwy = ''; if (!$qamwkmomamooqqic) { goto oomguqikqokqwgku; } $pkyyagewkiyckmwy = Domain::symcgieuakksimmu()->uikgwcuascgeissw($qamwkmomamooqqic); oomguqikqokqwgku: return $pkyyagewkiyckmwy; } }
