<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6668a93c651c2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription\Model; use Pmpr\Common\Subscription\Model\Extra as BaseClass; use Pmpr\Module\DomainManager\Model\Domain; use Pmpr\Module\OptimizationManager\Subscription\Traits\EngineTrait; class Extra extends BaseClass { use EngineTrait; public function aoqwywcqmoqaukkq() { $this->mkksewyosgeumwsa($this->mccagaqeagiikkec(self::kuqwimiimiqsimgo)->ugquamoakekwyiqg(Domain::class)->mkmssscwmeekwgqo()); parent::aoqwywcqmoqaukkq(); } }
