<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668682bdd9cf1             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription\Model; use Pmpr\Module\OptimizationManager\Subscription\Common; class Model extends Common { public function mameiwsayuyquoeq() { Plan::symcgieuakksimmu(); Subscription::symcgieuakksimmu(); Extra::symcgieuakksimmu(); Usage::symcgieuakksimmu(); } }
