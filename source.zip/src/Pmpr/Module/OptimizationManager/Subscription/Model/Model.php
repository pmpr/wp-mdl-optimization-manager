<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6673f43d60276             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription\Model; use Pmpr\Module\OptimizationManager\Subscription\Common; class Model extends Common { public function mameiwsayuyquoeq() { Plan::symcgieuakksimmu(); Subscription::symcgieuakksimmu(); Extra::symcgieuakksimmu(); Usage::symcgieuakksimmu(); } }
