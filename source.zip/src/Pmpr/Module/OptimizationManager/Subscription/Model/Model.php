<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fa77c22e0ce             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription\Model; use Pmpr\Module\OptimizationManager\Subscription\Common; class Model extends Common { public function mameiwsayuyquoeq() { Plan::symcgieuakksimmu(); Subscription::symcgieuakksimmu(); Extra::symcgieuakksimmu(); Usage::symcgieuakksimmu(); } }
