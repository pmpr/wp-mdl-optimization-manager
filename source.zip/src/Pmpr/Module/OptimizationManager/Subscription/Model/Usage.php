<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668f1c0e6e17c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription\Model; use Pmpr\Common\Subscription\Model\Usage as BaseClass; use Pmpr\Module\OptimizationManager\Subscription\Traits\EngineTrait; class Usage extends BaseClass { use EngineTrait; }
