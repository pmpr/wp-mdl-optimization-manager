<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ab90b7db1ad             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription\Model; use Pmpr\Common\Subscription\Model\Usage as BaseClass; use Pmpr\Module\OptimizationManager\Subscription\Traits\EngineTrait; class Usage extends BaseClass { use EngineTrait; }
