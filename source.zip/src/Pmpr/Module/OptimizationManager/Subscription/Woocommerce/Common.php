<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a8912ac32             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription\Woocommerce; use Pmpr\Module\OptimizationManager\Subscription\Common as BaseClass; use Pmpr\Module\OptimizationManager\Subscription\Traits\EngineTrait; abstract class Common extends BaseClass { use EngineTrait; }
