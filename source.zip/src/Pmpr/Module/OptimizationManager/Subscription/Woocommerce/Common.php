<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e41be607e2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription\Woocommerce; use Pmpr\Module\OptimizationManager\Subscription\Common as BaseClass; use Pmpr\Module\OptimizationManager\Subscription\Traits\EngineTrait; abstract class Common extends BaseClass { use EngineTrait; }
