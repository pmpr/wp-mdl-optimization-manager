<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6668a93c651c2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription\Woocommerce; use Pmpr\Module\OptimizationManager\Subscription\Common as BaseClass; use Pmpr\Module\OptimizationManager\Subscription\Traits\EngineTrait; abstract class Common extends BaseClass { use EngineTrait; }
