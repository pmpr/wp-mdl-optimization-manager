<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668107472aaf4             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription\Woocommerce; use Pmpr\Common\Subscription\Woocommerce\Checkout as BaseClass; use Pmpr\Module\OptimizationManager\Subscription\Traits\EngineTrait; class Checkout extends BaseClass { use EngineTrait; }
