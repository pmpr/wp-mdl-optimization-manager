<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e41be607e2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription\Woocommerce; use Pmpr\Module\OptimizationManager\Subscription\Common; class Woocommerce extends Common { public function mameiwsayuyquoeq() { Cart::symcgieuakksimmu(); Product::symcgieuakksimmu(); } }
