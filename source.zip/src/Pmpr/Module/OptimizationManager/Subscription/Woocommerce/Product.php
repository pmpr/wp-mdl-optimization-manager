<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a8912ac32             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription\Woocommerce; class Product extends Common { }
