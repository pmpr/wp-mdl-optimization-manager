<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6687081b48ec2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription\Woocommerce; use Pmpr\Common\Subscription\Woocommerce\Order as BaseClass; use Pmpr\Module\OptimizationManager\Subscription\Traits\EngineTrait; class Order extends BaseClass { use EngineTrait; }
