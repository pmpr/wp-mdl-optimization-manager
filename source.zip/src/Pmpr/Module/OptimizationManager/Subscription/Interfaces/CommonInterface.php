<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66aeb5d2abe77             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription\Interfaces; interface CommonInterface { const mykiyeswieqamagm = "\143\157\151\156"; const reqeqykqwgqmkqsc = "\x62\165\x64\x67\x65\164"; const oquukmukaoqegcuk = "\x75\163\x61\x67\x65\137\x69\144\x73"; const wogaqauoigwyaoig = "\167\145\x62\x5f\166\x69\x74\x61\154\x5f\x75\x73\x61\147\145"; const cgiaykosmmoyuagu = "\143\x72\x69\x74\x69\x63\x61\x6c\137\x63\x73\x73\x5f\x75\x73\x61\x67\145"; }
