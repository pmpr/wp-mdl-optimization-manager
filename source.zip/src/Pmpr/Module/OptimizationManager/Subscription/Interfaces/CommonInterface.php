<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a2f4544fcb3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription\Interfaces; interface CommonInterface { const mykiyeswieqamagm = "\x63\x6f\151\x6e"; const reqeqykqwgqmkqsc = "\142\x75\x64\147\145\164"; const oquukmukaoqegcuk = "\x75\163\141\147\x65\x5f\x69\144\163"; const wogaqauoigwyaoig = "\167\x65\x62\x5f\166\151\164\141\x6c\137\165\163\x61\147\x65"; const cgiaykosmmoyuagu = "\x63\162\x69\x74\151\143\x61\154\x5f\x63\x73\x73\x5f\x75\163\141\x67\145"; }
