<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6688fb4047973             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription\Interfaces; interface CommonInterface { const mykiyeswieqamagm = "\x63\x6f\151\156"; const reqeqykqwgqmkqsc = "\x62\x75\144\147\x65\x74"; const oquukmukaoqegcuk = "\x75\163\x61\147\145\x5f\151\x64\x73"; const wogaqauoigwyaoig = "\167\145\142\137\166\151\x74\141\154\x5f\165\163\141\x67\145"; const cgiaykosmmoyuagu = "\x63\x72\151\164\151\x63\x61\154\137\x63\163\163\x5f\165\x73\141\147\x65"; }
