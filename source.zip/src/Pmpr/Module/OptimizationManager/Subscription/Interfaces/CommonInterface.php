<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669ada84df097             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription\Interfaces; interface CommonInterface { const mykiyeswieqamagm = "\x63\x6f\151\x6e"; const reqeqykqwgqmkqsc = "\x62\x75\144\x67\145\164"; const oquukmukaoqegcuk = "\x75\163\141\x67\x65\137\151\x64\163"; const wogaqauoigwyaoig = "\167\145\142\x5f\x76\151\x74\x61\154\137\165\x73\141\x67\x65"; const cgiaykosmmoyuagu = "\143\162\151\164\151\x63\x61\x6c\x5f\143\x73\163\x5f\x75\163\x61\147\145"; }
