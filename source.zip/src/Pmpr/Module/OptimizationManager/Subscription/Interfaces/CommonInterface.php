<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668400e7ecf4b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription\Interfaces; interface CommonInterface { const mykiyeswieqamagm = "\143\157\x69\x6e"; const reqeqykqwgqmkqsc = "\x62\x75\x64\x67\145\164"; const oquukmukaoqegcuk = "\165\163\141\147\145\137\151\144\163"; const wogaqauoigwyaoig = "\x77\145\142\137\x76\151\x74\x61\154\137\x75\x73\x61\x67\145"; const cgiaykosmmoyuagu = "\143\x72\x69\164\x69\143\141\x6c\x5f\143\163\x73\137\165\163\x61\147\145"; }
