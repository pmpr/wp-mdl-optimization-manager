<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a8912ac32             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription\Interfaces; interface CommonInterface { const mykiyeswieqamagm = "\143\x6f\x69\x6e"; const reqeqykqwgqmkqsc = "\x62\x75\144\147\145\x74"; const wogaqauoigwyaoig = "\167\x65\x62\137\166\151\x74\141\x6c\x5f\x75\x73\x61\x67\145"; const cgiaykosmmoyuagu = "\x63\x72\x69\164\151\x63\x61\x6c\x5f\x63\163\163\137\165\163\x61\x67\x65"; }
