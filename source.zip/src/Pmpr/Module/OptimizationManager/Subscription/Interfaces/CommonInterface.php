<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66c508f028b24             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription\Interfaces; interface CommonInterface { const mykiyeswieqamagm = "\x63\157\151\x6e"; const reqeqykqwgqmkqsc = "\x62\165\144\x67\x65\164"; const oquukmukaoqegcuk = "\165\163\x61\x67\x65\x5f\151\144\x73"; const wogaqauoigwyaoig = "\x77\x65\x62\137\166\151\x74\x61\154\x5f\165\163\141\147\145"; const cgiaykosmmoyuagu = "\x63\162\x69\x74\x69\x63\141\x6c\x5f\x63\163\163\137\x75\x73\141\147\145"; }
