<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ab90b7db1ad             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription\Interfaces; interface CommonInterface { const mykiyeswieqamagm = "\143\157\x69\156"; const reqeqykqwgqmkqsc = "\142\x75\144\x67\145\x74"; const oquukmukaoqegcuk = "\x75\163\x61\x67\x65\137\151\x64\163"; const wogaqauoigwyaoig = "\167\x65\142\x5f\x76\151\164\141\x6c\137\x75\x73\141\147\x65"; const cgiaykosmmoyuagu = "\x63\162\151\164\151\143\141\154\x5f\x63\x73\x73\x5f\165\x73\141\x67\x65"; }
