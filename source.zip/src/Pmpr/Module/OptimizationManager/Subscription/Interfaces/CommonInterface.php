<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669c38b3da912             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription\Interfaces; interface CommonInterface { const mykiyeswieqamagm = "\x63\157\151\156"; const reqeqykqwgqmkqsc = "\142\x75\x64\x67\x65\x74"; const oquukmukaoqegcuk = "\165\163\141\x67\145\137\151\x64\163"; const wogaqauoigwyaoig = "\167\x65\x62\x5f\x76\151\x74\x61\x6c\x5f\165\163\141\x67\145"; const cgiaykosmmoyuagu = "\x63\x72\151\x74\x69\143\141\x6c\x5f\x63\x73\x73\x5f\x75\x73\141\x67\x65"; }
