<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6606962cb6677             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription\Interfaces; interface CommonInterface { const mykiyeswieqamagm = "\143\157\151\156"; const reqeqykqwgqmkqsc = "\x62\x75\x64\x67\145\x74"; const wogaqauoigwyaoig = "\167\145\x62\x5f\166\151\x74\141\x6c\137\165\163\x61\147\x65"; const cgiaykosmmoyuagu = "\x63\x72\151\x74\151\143\141\154\137\143\163\x73\137\165\163\x61\147\145"; }
