<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6686f09d04cd6             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription\Interfaces; interface CommonInterface { const mykiyeswieqamagm = "\143\157\151\x6e"; const reqeqykqwgqmkqsc = "\x62\x75\x64\147\x65\x74"; const oquukmukaoqegcuk = "\x75\x73\x61\147\145\x5f\x69\x64\x73"; const wogaqauoigwyaoig = "\x77\145\142\137\166\x69\164\141\x6c\x5f\x75\163\x61\147\x65"; const cgiaykosmmoyuagu = "\143\x72\x69\164\x69\143\x61\x6c\x5f\x63\163\163\x5f\165\163\x61\147\145"; }
