<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e41be607e2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription\Interfaces; interface CommonInterface { const mykiyeswieqamagm = "\143\157\x69\x6e"; const reqeqykqwgqmkqsc = "\142\165\x64\147\145\x74"; const wogaqauoigwyaoig = "\x77\145\142\137\166\151\x74\x61\154\137\x75\x73\x61\x67\145"; const cgiaykosmmoyuagu = "\143\162\151\x74\151\143\x61\154\137\143\x73\163\137\165\163\x61\147\145"; }
