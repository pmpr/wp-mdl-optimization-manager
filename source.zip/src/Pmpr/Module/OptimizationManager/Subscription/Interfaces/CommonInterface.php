<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6681a8b647924             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription\Interfaces; interface CommonInterface { const mykiyeswieqamagm = "\x63\157\x69\x6e"; const reqeqykqwgqmkqsc = "\142\x75\144\x67\x65\x74"; const oquukmukaoqegcuk = "\x75\x73\141\147\145\137\x69\144\x73"; const wogaqauoigwyaoig = "\167\145\142\137\166\151\164\141\x6c\x5f\165\x73\141\x67\x65"; const cgiaykosmmoyuagu = "\143\162\x69\164\x69\143\x61\x6c\137\x63\x73\163\137\x75\x73\x61\x67\x65"; }
