<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66b6188ad9125             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription\Interfaces; interface CommonInterface { const mykiyeswieqamagm = "\x63\157\x69\156"; const reqeqykqwgqmkqsc = "\x62\x75\x64\x67\145\x74"; const oquukmukaoqegcuk = "\165\x73\x61\x67\x65\137\x69\144\x73"; const wogaqauoigwyaoig = "\x77\145\x62\137\166\x69\164\x61\154\x5f\165\163\x61\x67\x65"; const cgiaykosmmoyuagu = "\143\x72\151\164\151\143\x61\x6c\137\143\x73\163\x5f\x75\163\x61\147\145"; }
