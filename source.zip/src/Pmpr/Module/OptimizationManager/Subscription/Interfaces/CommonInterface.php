<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6687081b48ec2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription\Interfaces; interface CommonInterface { const mykiyeswieqamagm = "\x63\x6f\151\x6e"; const reqeqykqwgqmkqsc = "\142\x75\x64\x67\x65\x74"; const oquukmukaoqegcuk = "\x75\163\x61\147\145\137\x69\144\x73"; const wogaqauoigwyaoig = "\x77\145\142\137\x76\151\164\141\x6c\x5f\x75\163\x61\x67\145"; const cgiaykosmmoyuagu = "\x63\x72\151\164\x69\143\x61\x6c\137\143\163\163\137\x75\x73\x61\x67\145"; }
