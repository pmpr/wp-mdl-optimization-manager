<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66c31d588b892             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription\Interfaces; interface CommonInterface { const mykiyeswieqamagm = "\x63\157\151\156"; const reqeqykqwgqmkqsc = "\142\165\144\147\x65\x74"; const oquukmukaoqegcuk = "\x75\x73\x61\147\x65\137\151\x64\163"; const wogaqauoigwyaoig = "\x77\x65\x62\137\x76\x69\164\x61\x6c\x5f\x75\x73\x61\147\x65"; const cgiaykosmmoyuagu = "\x63\x72\151\164\151\x63\141\x6c\137\143\x73\x73\x5f\x75\163\141\147\145"; }
