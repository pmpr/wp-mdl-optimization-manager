<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb56e3d281a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription\Interfaces; interface CommonInterface { const mykiyeswieqamagm = "\x63\157\x69\156"; const reqeqykqwgqmkqsc = "\x62\x75\144\x67\145\x74"; const oquukmukaoqegcuk = "\165\163\141\x67\145\137\x69\x64\163"; const wogaqauoigwyaoig = "\x77\x65\142\137\x76\151\164\x61\x6c\x5f\x75\x73\141\x67\145"; const cgiaykosmmoyuagu = "\143\162\x69\x74\151\143\141\x6c\x5f\x63\163\x73\137\x75\x73\141\147\145"; }
