<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66871ee971196             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription\Interfaces; interface CommonInterface { const mykiyeswieqamagm = "\143\157\x69\x6e"; const reqeqykqwgqmkqsc = "\x62\165\144\x67\x65\164"; const oquukmukaoqegcuk = "\x75\163\x61\147\145\x5f\x69\x64\x73"; const wogaqauoigwyaoig = "\x77\145\x62\137\166\151\x74\x61\x6c\x5f\x75\163\x61\x67\145"; const cgiaykosmmoyuagu = "\143\x72\151\164\x69\x63\x61\x6c\x5f\x63\x73\x73\137\165\x73\141\147\x65"; }
