<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668c5b679666b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription\Interfaces; interface CommonInterface { const mykiyeswieqamagm = "\x63\157\151\x6e"; const reqeqykqwgqmkqsc = "\142\x75\x64\147\x65\164"; const oquukmukaoqegcuk = "\165\x73\141\x67\x65\137\x69\144\163"; const wogaqauoigwyaoig = "\x77\145\x62\x5f\x76\151\x74\141\x6c\x5f\165\163\141\x67\145"; const cgiaykosmmoyuagu = "\x63\162\151\164\x69\x63\x61\x6c\x5f\143\x73\x73\x5f\x75\163\141\147\145"; }
