<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66868667851c5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription\Interfaces; interface CommonInterface { const mykiyeswieqamagm = "\x63\x6f\x69\156"; const reqeqykqwgqmkqsc = "\142\165\x64\x67\145\164"; const oquukmukaoqegcuk = "\165\163\141\147\x65\137\x69\x64\163"; const wogaqauoigwyaoig = "\167\145\x62\137\166\151\164\141\154\137\x75\x73\141\147\145"; const cgiaykosmmoyuagu = "\143\162\x69\164\151\143\x61\x6c\137\x63\x73\163\137\165\163\141\147\145"; }
