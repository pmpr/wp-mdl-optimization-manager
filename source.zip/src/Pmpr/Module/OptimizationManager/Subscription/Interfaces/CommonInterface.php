<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6673f43d60276             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription\Interfaces; interface CommonInterface { const mykiyeswieqamagm = "\143\157\x69\x6e"; const reqeqykqwgqmkqsc = "\x62\165\x64\x67\x65\x74"; const oquukmukaoqegcuk = "\165\163\x61\147\145\x5f\151\144\x73"; const wogaqauoigwyaoig = "\x77\x65\x62\137\x76\151\164\x61\154\137\165\163\141\x67\145"; const cgiaykosmmoyuagu = "\x63\x72\x69\164\x69\x63\141\154\x5f\x63\x73\x73\x5f\165\163\141\147\x65"; }
