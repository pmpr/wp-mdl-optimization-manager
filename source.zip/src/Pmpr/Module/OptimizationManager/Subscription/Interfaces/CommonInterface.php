<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668682bdd9cf1             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription\Interfaces; interface CommonInterface { const mykiyeswieqamagm = "\143\157\x69\156"; const reqeqykqwgqmkqsc = "\x62\165\144\x67\x65\x74"; const oquukmukaoqegcuk = "\x75\x73\x61\x67\145\x5f\x69\144\x73"; const wogaqauoigwyaoig = "\x77\145\x62\137\x76\151\x74\141\154\137\x75\x73\x61\147\145"; const cgiaykosmmoyuagu = "\143\x72\x69\164\151\x63\141\x6c\x5f\x63\x73\x73\137\x75\163\x61\147\x65"; }
