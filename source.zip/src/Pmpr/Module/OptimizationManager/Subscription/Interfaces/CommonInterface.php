<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66788387d2261             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription\Interfaces; interface CommonInterface { const mykiyeswieqamagm = "\x63\157\151\x6e"; const reqeqykqwgqmkqsc = "\142\165\x64\x67\x65\x74"; const oquukmukaoqegcuk = "\x75\163\141\x67\145\137\x69\x64\163"; const wogaqauoigwyaoig = "\167\x65\142\x5f\166\x69\164\x61\x6c\x5f\165\x73\141\147\145"; const cgiaykosmmoyuagu = "\x63\162\151\164\151\x63\141\154\x5f\x63\x73\x73\x5f\x75\163\141\147\x65"; }
