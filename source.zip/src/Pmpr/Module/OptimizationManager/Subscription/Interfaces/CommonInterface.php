<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668daba42442f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription\Interfaces; interface CommonInterface { const mykiyeswieqamagm = "\x63\x6f\x69\156"; const reqeqykqwgqmkqsc = "\x62\x75\x64\147\x65\x74"; const oquukmukaoqegcuk = "\x75\x73\x61\x67\x65\x5f\x69\144\163"; const wogaqauoigwyaoig = "\x77\x65\x62\x5f\x76\151\x74\141\154\137\x75\x73\141\147\145"; const cgiaykosmmoyuagu = "\143\162\x69\x74\x69\x63\x61\x6c\137\143\x73\x73\x5f\x75\163\141\x67\145"; }
