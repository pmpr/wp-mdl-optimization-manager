<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6668a93c651c2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription\Interfaces; interface CommonInterface { const mykiyeswieqamagm = "\143\x6f\151\156"; const reqeqykqwgqmkqsc = "\142\165\144\x67\145\x74"; const wogaqauoigwyaoig = "\167\145\142\x5f\166\x69\x74\x61\154\137\165\163\x61\x67\145"; const cgiaykosmmoyuagu = "\x63\162\x69\x74\151\x63\141\x6c\137\x63\163\x73\x5f\165\x73\x61\147\145"; }
