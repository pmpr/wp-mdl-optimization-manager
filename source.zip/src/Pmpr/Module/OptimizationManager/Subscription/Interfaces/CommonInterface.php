<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668f1c0e6e17c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription\Interfaces; interface CommonInterface { const mykiyeswieqamagm = "\143\x6f\x69\156"; const reqeqykqwgqmkqsc = "\x62\x75\144\x67\145\x74"; const oquukmukaoqegcuk = "\x75\x73\141\147\x65\137\151\144\x73"; const wogaqauoigwyaoig = "\167\145\142\x5f\x76\x69\x74\141\x6c\137\165\x73\141\x67\x65"; const cgiaykosmmoyuagu = "\143\162\x69\164\x69\x63\141\x6c\x5f\x63\x73\x73\137\165\x73\141\147\x65"; }
