<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6689580cec3a1             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription\Interfaces; interface CommonInterface { const mykiyeswieqamagm = "\x63\x6f\151\156"; const reqeqykqwgqmkqsc = "\x62\165\x64\x67\x65\164"; const oquukmukaoqegcuk = "\x75\x73\x61\x67\x65\x5f\151\x64\x73"; const wogaqauoigwyaoig = "\167\x65\142\137\166\x69\x74\141\x6c\137\165\x73\141\x67\145"; const cgiaykosmmoyuagu = "\x63\162\151\x74\x69\143\141\154\137\143\163\163\x5f\165\163\141\147\x65"; }
