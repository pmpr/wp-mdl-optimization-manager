<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669eebb8a3e37             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription\Interfaces; interface CommonInterface { const mykiyeswieqamagm = "\x63\x6f\x69\156"; const reqeqykqwgqmkqsc = "\142\x75\x64\147\145\164"; const oquukmukaoqegcuk = "\x75\163\141\147\x65\137\x69\x64\163"; const wogaqauoigwyaoig = "\167\145\x62\137\x76\151\x74\x61\154\x5f\165\163\141\147\145"; const cgiaykosmmoyuagu = "\x63\162\x69\164\151\x63\141\154\137\x63\163\163\x5f\x75\x73\x61\147\x65"; }
