<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668f1c0e6e17c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Ticket; use Pmpr\Common\Foundation\Frontend\Page as BaseClass; use Pmpr\Module\OptimizationManager\Setting; class Page extends BaseClass { public function qiccuiwooiquycsg() { $this->wegcaymyqqoyewmw("\x77\x70\x2d\163\x70\145\x65\144\55\162\x65\x71\x75\145\x73\164")->gswweykyogmsyawy(__("\x4f\160\x74\151\x6d\x69\172\141\164\x69\x6f\156\x20\115\x6f\144\165\x6c\145\40\122\145\x71\165\x65\x73\164\x20\x50\x61\x67\x65", PR__MDL__OPTIMIZATION_MANAGER))->wmsaakuicamguoam((int) Setting::symcgieuakksimmu()->giiuwsmyumqwwiyq(Setting::ssoyyscooyasegqi, 0)); } public function rsysgcucogueguuk() : array { return []; } }
